<p align="center">
  <img alt="CometChat" src="https://assets.cometchat.io/website/images/logos/banner.png">
</p>

# CometChat Flutter UI Kit

CometChat Flutter UIKit provides a pre-built user interface kit that developers can use to quickly integrate a reliable & fully-featured chat experience into an existing or a new mobile app.<br />
<div style="
    display: flex;
    align-items: center;
    justify-content: center;">
   <img src="./screenshots/overview_cometchat_screens.png" />
</div>

## Prerequisites

**iOS**
- XCode
- Pod (CocoaPods) for iOS
- An iOS device or emulator with iOS 12.0 or above.
  
**Android**
- Android Studio
- Android device or emulator with Android version 5.0 or above.
  
---

## How to Configure Your Own Application with CometChatBuilder Settings
This sample app demonstrates the usage of **CometChat Builder** configuration system. You can easily integrate the same configuration system into your own Android application by following these guided steps:

### What is CometChat Builder?
CometChat Builder is CometChat's configuration system that allows you to customize chat features, UI components, and styling through a simple JSON configuration file. The builder plugin automatically generates Kotlin constants and applies styling based on your configuration.

---

## Platform Requirements

For running the chat builder in your own app you will need to:

### iOS

Update your `Podfile` and set the iOS platform to 13.0 or higher:
```
platform :ios, '13.0'
```

### Android

Change the `ndkVersion` and `minSdk` in your `android/app/build.gradle.kts`:

```kotlin
android {
    // Other Settings
    ndkVersion = "27.0.12077973"

    defaultConfig {
        // Other Settings
        minSdk = 24
    }
}
```

---

## ⚡ Import the CometChatBuilder Sample App Directly as a Module

You can use the pre-configured **CometChatBuilder Sample App** directly in your project as a module. This option is ideal if you want a ready-made module to plug-and-play, or wish to migrate features from the sample app to your main app.

### 🛠️ Integration Guide

Follow these steps to integrate CometChat Builder into your Flutter project:

1. **Download the Chat Builder app from the dashboard.**

2. **Copy the `chat_builder` project directory** and paste it in your app.

3. **Copy all the contents from the assets directory of the chat_builder and add it to your project assets.**
   - **Source:** `chat_builder/assets/`
   - **Destination:** `assets/`

4. **Update your `pubspec.yaml` with the following changes:**
    ```
    dependencies:
      // other dependencies
      chat_builder:
        path: ./chat_builder
    flutter:
      assets:
        - assets/
        - assets/sample_app/
      fonts:
        - family: arial
          fonts:
            - asset: assets/fonts/arial_regular.ttf
            - asset: assets/fonts/arial_medium.ttf
            - asset: assets/fonts/arial_bold.ttf
        - family: inter
          fonts:
            - asset: assets/fonts/inter_regular.otf
            - asset: assets/fonts/inter_medium.otf
            - asset: assets/fonts/inter_bold.otf
        - family: roboto
          fonts:
            - asset: assets/fonts/roboto_regular.ttf
            - asset: assets/fonts/roboto_medium.ttf
            - asset: assets/fonts/roboto_bold.ttf
        - family: times New Roman
          fonts:
            - asset: assets/fonts/times_new_roman_regular.ttf
            - asset: assets/fonts/times_new_roman_medium.otf
            - asset: assets/fonts/times_new_roman_bold.otf
    ```

5. **Run the following commands in your terminal:**
    ```
    flutter pub get
    cd ios
    pod install
    ```

6. **In the main file of your project, add the following lines before `runApp()`:**
    ```
    WidgetsFlutterBinding.ensureInitialized();
    BuilderSettingsHelper.loadFromAsset();
    ```

7. **To launch the Chat Builder Screens as required:**
   
- If CometChat is **not initialized** or the user is **not logged in**:
  ```
  ChatBuilder.launchBuilder(context);
  ```

- If CometChat is **initialized** and user is **logged in** and want to open Messages Screen:

  In case of ***User*** -
  ```
  ChatBuilder.launchMessages(context: context, user: user);
  ```

  In case of ***Group*** -
  ```
  ChatBuilder.launchMessages(context: context, group: group);
  ```
---

## 🔎 Available Builder Settings Categories

The Builder configuration supports the following categories:

- **🔧 Core Messaging Experience** - Basic chat features (typing, file sharing, etc.)
- **🎯 Deeper User Engagement** - Advanced features (reactions, polls, translation)
- **🤖 AI User Copilot** - AI-powered features (smart replies, conversation starters)
- **👥 Group Management** - Group creation, member management
- **🛡️ Moderator Controls** - User moderation (kick, ban, promote)
- **📞 Voice & Video Calling** - Call-related features
- **🎨 Layout & Styling** - UI customization and theming

---

## 🚀 Benefits of Using CometChat Builder

✅ **Easy Configuration**: Change features without modifying code  
✅ **Type-Safe Constants**: Auto-generated Dart constants  
✅ **Consistent Styling**: Automatic theme generation  
✅ **Feature Toggling**: Enable/disable features dynamically  
✅ **No Code Changes**: Modify behavior through JSON configuration

---

## Need Help?

- 📖 [CometChat Documentation](https://www.cometchat.com/docs/ui-kit/flutter/overview)
- 🎫 [Create Support Ticket](https://help.cometchat.com/hc/en-us)
- 💬 [CometChat Dashboard](https://app.cometchat.com/)
