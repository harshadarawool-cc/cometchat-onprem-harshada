import 'package:flutter/material.dart';

class BuilderSettings {
  static bool isQRScanned = false;
  static bool isLoadedFirstTime = true;
}

class CoreMessagingExperience {
  static bool typingIndicator = true;
  static bool threadConversationAndReplies = true;
  static bool photosSharing = true;
  static bool videoSharing = true;
  static bool audioSharing = true;
  static bool fileSharing = true;
  static bool editMessage = true;
  static bool deleteMessage = true;
  static bool messageDeliveryAndReadReceipts = true;
  static bool userAndFriendsPresence = true;
  static bool conversationAndAdvancedSearch = true;
  static bool moderation = true;
  static bool quotedReplies = false;
  static bool markAsUnread = false;
}

class DeeperUserEngagement {
  static bool mentions = true;
  static bool mentionAll = true;
  static bool reactions = true;
  static bool messageTranslation = true;
  static bool polls = true;
  static bool collaborativeWhiteboard = true;
  static bool collaborativeDocument = true;
  static bool voiceNotes = true;
  static bool emojis = true;
  static bool stickers = true;
  static bool userInfo = true;
  static bool groupInfo = true;
}

class AiUserCopilot {
  static bool conversationStarter = false;
  static bool conversationSummary = false;
  static bool smartReply = false;
}

class UserManagement {
  static bool friendsOnly = true;
}

class GroupManagement {
  static bool createGroup = true;
  static bool addMembersToGroups = true;
  static bool joinLeaveGroup = true;
  static bool deleteGroup = true;
  static bool viewGroupMembers = true;
}

class ModeratorControls {
  static bool kickUsers = true;
  static bool banUsers = true;
  static bool promoteDemoteMembers = true;
  static bool reportMessage = true;
}

class PrivateMessagingWithinGroups {
  static bool sendPrivateMessageToGroupMembers = true;
}

class VoiceAndVideoCalling {
  static bool oneOnOneVoiceCalling = true;
  static bool oneOnOneVideoCalling = true;
  static bool groupVideoConference = true;
  static bool groupVoiceConference = true;
}

class Layout {
  static bool withSideBar = true;
  static String chatType = "user";
  static bool compactMessageComposer = false;
}

class BuilderColor {
  static Color? brandColor = Color(0xFF6852D6);
  static Color? primaryTextLight = Color(0xFF141414);
  static Color? primaryTextDark = Color(0xFFFFFFFF);
  static Color? secondaryTextLight = Color(0xFF727272);
  static Color? secondaryTextDark = Color(0xFF989898);
}

class BuilderTypography {
  static String font = "roboto";
  static String size = "default";
}

class NoCodeStyles {
  static String buttonBackGround = "#141414";
  static String buttonShape = "rounded";
  static String openIcon = "https://cdn.jsdelivr.net/npm/@cometchat/chat-embed@latest/dist/icons/docked_open_icon.svg";
  static String closeIcon = "https://cdn.jsdelivr.net/npm/@cometchat/chat-embed@latest/dist/icons/docked_close_icon.svg";
  static String customJs = "";
  static String customCss = "";
  static String dockedAlignment = "right";
}

class Agent {
  static bool chatHistory = true;
  static bool newChat = true;
  static String agentIcon = "";
  static bool showAgentIcon = true;
}