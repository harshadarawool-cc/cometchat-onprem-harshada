import 'dart:convert';
import 'package:flutter/services.dart' show rootBundle;
import 'package:flutter/material.dart';
import '../utils/constant_utils.dart';
import 'builder_settings.dart';

class BuilderSettingsHelper {

  static getBuilderVersion(){
    return "v5.2.12";
  }

  static Color _fromHex(String hex) {
    hex = hex.replaceAll('#', '');
    if (hex.length == 6) {
      hex = 'FF$hex';
    } else if (hex.length == 8) {
      hex = hex.substring(6, 8) + hex.substring(0, 6);
    } else {
      throw FormatException('Invalid hex color format: $hex');
    }
    return Color(int.parse(hex, radix: 16));
  }

  static Future<void> load(Map<String, dynamic> json) async {
    final settings = json['settings'] ?? {};
    final chatFeatures = settings['chatFeatures'] ?? {};
    final callFeatures = settings['callFeatures'] ?? {};
    final layout = settings['layout'] ?? {};
    final style = settings['style'] ?? {};
    final noCode = settings['noCode'] ?? {};
    final agent = settings['agent'] ?? {};

    // CoreMessagingExperience
    final core = chatFeatures['coreMessagingExperience'] ?? {};
    CoreMessagingExperience.typingIndicator = core['typingIndicator'] ?? false;
    CoreMessagingExperience.threadConversationAndReplies = core['threadConversationAndReplies'] ?? true;
    CoreMessagingExperience.photosSharing = core['photosSharing'] ?? true;
    CoreMessagingExperience.videoSharing = core['videoSharing'] ?? false;
    CoreMessagingExperience.audioSharing = core['audioSharing'] ?? true;
    CoreMessagingExperience.fileSharing = core['fileSharing'] ?? true;
    CoreMessagingExperience.editMessage = core['editMessage'] ?? true;
    CoreMessagingExperience.deleteMessage = core['deleteMessage'] ?? true;
    CoreMessagingExperience.messageDeliveryAndReadReceipts = core['messageDeliveryAndReadReceipts'] ?? false;
    CoreMessagingExperience.userAndFriendsPresence = core['userAndFriendsPresence'] ?? false;
    CoreMessagingExperience.conversationAndAdvancedSearch = core['conversationAndAdvancedSearch'] ?? true;
    CoreMessagingExperience.moderation = core['moderation'] ?? true;
    CoreMessagingExperience.quotedReplies = core['quotedReplies'] ?? false;
    CoreMessagingExperience.markAsUnread = core['markAsUnread'] ?? false;

    // DeeperUserEngagement
    final deeper = chatFeatures['deeperUserEngagement'] ?? {};
    DeeperUserEngagement.mentions = deeper['mentions'] ?? false;
    DeeperUserEngagement.mentionAll = deeper['mentionAll'] ?? false;
    DeeperUserEngagement.reactions = deeper['reactions'] ?? true;
    DeeperUserEngagement.messageTranslation = deeper['messageTranslation'] ?? true;
    DeeperUserEngagement.polls = deeper['polls'] ?? true;
    DeeperUserEngagement.collaborativeWhiteboard = deeper['collaborativeWhiteboard'] ?? true;
    DeeperUserEngagement.collaborativeDocument = deeper['collaborativeDocument'] ?? true;
    DeeperUserEngagement.voiceNotes = deeper['voiceNotes'] ?? true;
    DeeperUserEngagement.emojis = deeper['emojis'] ?? true;
    DeeperUserEngagement.stickers = deeper['stickers'] ?? true;
    DeeperUserEngagement.userInfo = deeper['userInfo'] ?? true;
    DeeperUserEngagement.groupInfo = deeper['groupInfo'] ?? false;

    // AiUserCopilot
    final ai = chatFeatures['aiUserCopilot'] ?? {};
    AiUserCopilot.conversationStarter = ai['conversationStarter'] ?? false;
    AiUserCopilot.conversationSummary = ai['conversationSummary'] ?? false;
    AiUserCopilot.smartReply = ai['smartReply'] ?? false;

    // GroupManagement
    final group = chatFeatures['groupManagement'] ?? {};
    GroupManagement.createGroup = group['createGroup'] ?? true;
    GroupManagement.addMembersToGroups = group['addMembersToGroups'] ?? true;
    GroupManagement.joinLeaveGroup = group['joinLeaveGroup'] ?? true;
    GroupManagement.deleteGroup = group['deleteGroup'] ?? true;
    GroupManagement.viewGroupMembers = group['viewGroupMembers'] ?? true;

    // ModeratorControls
    final mod = chatFeatures['moderatorControls'] ?? {};
    ModeratorControls.kickUsers = mod['kickUsers'] ?? true;
    ModeratorControls.banUsers = mod['banUsers'] ?? true;
    ModeratorControls.promoteDemoteMembers =
        mod['promoteDemoteMembers'] ?? true;
    ModeratorControls.reportMessage = mod['reportMessage'] ?? true;

    // PrivateMessagingWithinGroups
    final pm = chatFeatures['privateMessagingWithinGroups'] ?? {};
    PrivateMessagingWithinGroups.sendPrivateMessageToGroupMembers =
        pm['sendPrivateMessageToGroupMembers'] ?? true;

    // VoiceAndVideoCalling
    final voiceVideo = callFeatures['voiceAndVideoCalling'] ?? {};
    VoiceAndVideoCalling.oneOnOneVoiceCalling = voiceVideo['oneOnOneVoiceCalling'] ?? true;
    VoiceAndVideoCalling.oneOnOneVideoCalling = voiceVideo['oneOnOneVideoCalling'] ?? true;
    VoiceAndVideoCalling.groupVideoConference = voiceVideo['groupVideoConference'] ?? true;
    VoiceAndVideoCalling.groupVoiceConference = voiceVideo['groupVoiceConference'] ?? true;

    // Layout
    Layout.withSideBar = layout['withSideBar'] ?? true;
    TabConstants.tabs = List<String>.from(layout['tabs'] ?? ["chats", "calls", "users", "groups"]);
    Layout.chatType = layout['chatType'] ?? "user";
    Layout.compactMessageComposer = layout['compactMessageComposer'] ?? false;

    // BuilderColor
    final color = style['color'] ?? {};
    BuilderColor.brandColor = _fromHex(color['brandColor']);
    BuilderColor.primaryTextLight = _fromHex(color['primaryTextLight']);
    BuilderColor.primaryTextDark = _fromHex(color['primaryTextDark']);
    BuilderColor.secondaryTextLight = _fromHex(color['secondaryTextLight']);
    BuilderColor.secondaryTextDark = _fromHex(color['secondaryTextDark']);

    // Typography
    final typography = style['typography'] ?? {};
    BuilderTypography.font = typography['font'] ?? "roboto";
    BuilderTypography.size = typography['size'] ?? "default";

    // NoCodeStyles
    final noCodeStyles = noCode['styles'] ?? {};
    NoCodeStyles.buttonBackGround = noCodeStyles['buttonBackGround'] ?? "#141414";
    NoCodeStyles.buttonShape = noCodeStyles['buttonShape'] ?? "rounded";
    NoCodeStyles.openIcon = noCodeStyles['openIcon'] ?? "https://cdn.jsdelivr.net/npm/@cometchat/chat-embed@latest/dist/icons/docked_open_icon.svg";
    NoCodeStyles.closeIcon = noCodeStyles['closeIcon'] ?? "https://cdn.jsdelivr.net/npm/@cometchat/chat-embed@latest/dist/icons/docked_close_icon.svg";
    NoCodeStyles.customJs = noCodeStyles['customJs'] ?? "";
    NoCodeStyles.customCss = noCodeStyles['customCss'] ?? "";
    NoCodeStyles.dockedAlignment = noCodeStyles['dockedAlignment'] ?? "right";

    // Agent
    Agent.chatHistory = agent['chatHistory'] ?? true;
    Agent.newChat = agent['newChat'] ?? true;
    Agent.agentIcon = agent['agentIcon'] ?? "";
    Agent.showAgentIcon = agent['showAgentIcon'] ?? true;
  }

  static loadFromAsset() async {
    final String jsonString = await rootBundle.loadString('assets/sample_app/cometchat-builder-settings.json');
    final Map<String, dynamic> json = jsonDecode(jsonString);
    await load(json);
  }

}