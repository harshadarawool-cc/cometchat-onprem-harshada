import 'package:flutter/material.dart';
import 'package:cometchat_chat_uikit/cometchat_chat_uikit.dart';
import 'package:cometchat_chat_uikit/cometchat_chat_uikit.dart' as cc;
import 'package:get/get.dart';
import 'package:chat_builder/builder/builder_settings.dart';
import '../utils/page_manager.dart';
import 'cometchat_thread_controller.dart';

class CometChatThread extends StatefulWidget {
  const CometChatThread(
      {this.user, this.group, required this.message, this.template, this.messageId, super.key});

  final User? user;
  final Group? group;
  final BaseMessage message;
  final CometChatMessageTemplate? template;
  final int? messageId;

  @override
  State<CometChatThread> createState() => _CometChatThreadState();
}

class _CometChatThreadState extends State<CometChatThread> {
  late CometChatThreadController threadController;

  late CometChatColorPalette colorPalette;
  late CometChatTypography typography;
  late CometChatSpacing spacing;

  @override
  void initState() {
    super.initState();
    threadController = Get.put(
      CometChatThreadController(widget.user, widget.group),
      permanent: false, // Ensures proper disposal
    );
  }

  @override
  void dispose() {
    Get.delete<CometChatThreadController>(); // Cleanup controller
    super.dispose();
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    typography = CometChatThemeHelper.getTypography(context);
    colorPalette = CometChatThemeHelper.getColorPalette(context);
    spacing = CometChatThemeHelper.getSpacing(context);
  }

  CometChatMentionsFormatter getMentionsTap() {
    return CometChatMentionsFormatter(
      user: widget.user,
      group: widget.group,
      onMentionTap: (mention, mentionedUser, {message}) {
        if (mentionedUser.uid != CometChatUIKit.loggedInUser!.uid) {
          PageManager().navigateToMessages(
            context: context,
            user: mentionedUser,
          );
        }
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return GetBuilder<CometChatThreadController>(
      builder: (controller) {
        return Scaffold(
          backgroundColor: colorPalette.background1,
          resizeToAvoidBottomInset:
              true, // Ensures layout adjusts for the keyboard
          appBar: CometChatMessageHeader(
            user: widget.user,
            group: widget.group,
            usersStatusVisibility: CoreMessagingExperience.userAndFriendsPresence,
            hideVideoCallButton: (widget.user != null && VoiceAndVideoCalling.oneOnOneVideoCalling) ||
                (widget.group != null && VoiceAndVideoCalling.groupVideoConference)
                ? ((controller.user?.blockedByMe != null &&
                controller.user?.blockedByMe! == true) ||
                (controller.group?.hasJoined == false ||
                    controller.group?.isBannedFromGroup == true))
                : false,
            hideVoiceCallButton: (widget.user != null && VoiceAndVideoCalling.oneOnOneVideoCalling) ||
                (widget.group != null && VoiceAndVideoCalling.groupVideoConference)
                ? ((controller.user?.blockedByMe != null &&
                controller.user?.blockedByMe! == true) ||
                (controller.group?.hasJoined == false ||
                    controller.group?.isBannedFromGroup == true))
                : false,
            padding: EdgeInsets.symmetric(
              vertical: spacing.padding2 ?? 0,
              horizontal: spacing.padding4 ?? 0,
            ),
            listItemView: (group, user, context) {
              var name = "";
              if (widget.message.sender != null &&
                  widget.message.sender?.uid ==
                      CometChatUIKit.loggedInUser?.uid) {
                name = widget.message.sender?.name ?? "";
              } else {
                name = group != null ? group.name : user?.name ?? "";
              }
              return Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    cc.Translations.of(context).thread,
                    style: TextStyle(
                      color: colorPalette.textPrimary,
                      fontSize: typography.heading2?.bold?.fontSize,
                      fontFamily: typography.heading2?.bold?.fontFamily,
                      fontWeight: typography.heading2?.bold?.fontWeight,
                    ),
                  ),
                  Expanded(
                    child: Text(
                      name,
                      style: TextStyle(
                        overflow: TextOverflow.ellipsis,
                        color: colorPalette.textSecondary,
                        fontSize: typography.caption1?.regular?.fontSize,
                        fontFamily: typography.caption1?.regular?.fontFamily,
                        fontWeight: typography.caption1?.regular?.fontWeight,
                      ),
                    ),
                  ),
                ],
              );
            },
            messageHeaderStyle: CometChatMessageHeaderStyle(
              backIconColor: colorPalette.iconPrimary,
              backgroundColor: colorPalette.background1,
              border: Border(
                top: BorderSide.none,
                right: BorderSide.none,
                bottom: BorderSide(
                  width: 1.0,
                  color: colorPalette.borderLight ?? Colors.transparent,
                  style: BorderStyle.solid,
                ),
                left: BorderSide(
                  width: 1.0,
                  color: colorPalette.borderLight ?? Colors.transparent,
                  style: BorderStyle.solid,
                ),
              ),
            ),
          ),
          body: LayoutBuilder(
            builder: (context, constraints) {
              final keyboardHeight = MediaQuery.of(context).viewInsets.bottom;
              final totalHeight = constraints.maxHeight;

              final composerHeight = 60.0;
              final initialHeaderHeight = totalHeight * 0.3;

              // Adjust the height if keyboard is open
              final availableHeaderHeight = keyboardHeight > 0
                  ? totalHeight - composerHeight - keyboardHeight - 16
                  : initialHeaderHeight;

              return Container(
                color: colorPalette.background3,
                child: Column(
                  children: [
                    SizedBox(
                      height: availableHeaderHeight,
                      child: CometChatThreadedHeader(
                        receiptsVisibility: CoreMessagingExperience.messageDeliveryAndReadReceipts,
                        height: availableHeaderHeight,
                        parentMessage: widget.message,
                        loggedInUser: CometChatUIKit.loggedInUser!,
                        template: widget.template,
                      ),
                    ),
                    Expanded(
                      child: GestureDetector(
                        onTap: () => FocusScope.of(context).unfocus(),
                        child: getMessageList(
                            widget.user, widget.group, context, widget.message),
                      ),
                    ),
                    getComposer(controller),
                  ],
                ),
              );
            },
          ),
        );
      },
    );
  }

  Widget getMessageList(
      User? user, Group? group, context, BaseMessage parentMessage) {
    MessagesRequestBuilder? requestBuilder = MessagesRequestBuilder();

    requestBuilder = MessagesRequestBuilder()
      ..parentMessageId = parentMessage.id;

    return CometChatMessageList(
      hideReplyOption: !CoreMessagingExperience.quotedReplies,
      user: user,
      group: group,
      messagesRequestBuilder: requestBuilder,
      textFormatters: [
        CometChatEmailFormatter(),
        CometChatPhoneNumberFormatter(),
        CometChatUrlFormatter(),
        getMentionsTap(),
      ],
      hideReplyInThreadOption: !CoreMessagingExperience.threadConversationAndReplies,
      hideEditMessageOption: !CoreMessagingExperience.editMessage,
      hideDeleteMessageOption: !CoreMessagingExperience.deleteMessage,
      receiptsVisibility: CoreMessagingExperience.messageDeliveryAndReadReceipts,
      hideReactionOption: !DeeperUserEngagement.reactions,
      hideTranslateMessageOption: !DeeperUserEngagement.messageTranslation,
      enableConversationStarters: AiUserCopilot.conversationStarter,
      enableSmartReplies: AiUserCopilot.smartReply,
      hideMessagePrivatelyOption: !PrivateMessagingWithinGroups.sendPrivateMessageToGroupMembers,
      hideFlagOption: !ModeratorControls.reportMessage,
      messageId: widget.messageId,
    );
  }

  Widget getComposer(CometChatThreadController controller) {
    if (controller.user != null &&
        controller.user?.blockedByMe != null &&
        controller.user?.blockedByMe! == true) {
      return _buildBlockedUserSection(controller);
    } else if (controller.group != null &&
        (controller.group?.hasJoined == false ||
            controller.group?.isBannedFromGroup == true)) {
      return _buildKickedFromGroup(controller);
    } else if (Layout.compactMessageComposer) {
      return CometChatCompactMessageComposer(
        user: widget.user,
        group: widget.group,
        parentMessageId: widget.message.id,
        disableTypingEvents: !CoreMessagingExperience.typingIndicator,
        disableMentions: !DeeperUserEngagement.mentions,
        disableMentionAll: !DeeperUserEngagement.mentionAll,
        hidePollsOption: !DeeperUserEngagement.polls,
        hideCollaborativeWhiteboardOption:
        !DeeperUserEngagement.collaborativeWhiteboard,
        hideCollaborativeDocumentOption:
        !DeeperUserEngagement.collaborativeDocument,
        hideVoiceRecordingButton: !DeeperUserEngagement.voiceNotes,
        hideStickersButton: !DeeperUserEngagement.stickers,
        hideTakePhotoOption: !CoreMessagingExperience.photosSharing,
        hideImageAttachmentOption: !CoreMessagingExperience.photosSharing,
        hideVideoAttachmentOption: !CoreMessagingExperience.videoSharing,
        hideAudioAttachmentOption: !CoreMessagingExperience.audioSharing,
        hideFileAttachmentOption: !CoreMessagingExperience.fileSharing,
        hideAttachmentButton: !(CoreMessagingExperience.photosSharing ||
            CoreMessagingExperience.videoSharing ||
            CoreMessagingExperience.audioSharing ||
            CoreMessagingExperience.fileSharing),
      );
    } else {
      return CometChatMessageComposer(
        user: widget.user,
        group: widget.group,
        parentMessageId: widget.message.id,
        disableTypingEvents: !CoreMessagingExperience.typingIndicator,
        disableMentions: !DeeperUserEngagement.mentions,
        disableMentionAll: !DeeperUserEngagement.mentionAll,
        hidePollsOption: !DeeperUserEngagement.polls,
        hideCollaborativeWhiteboardOption: !DeeperUserEngagement.collaborativeWhiteboard,
        hideCollaborativeDocumentOption: !DeeperUserEngagement.collaborativeDocument,
        hideVoiceRecordingButton: !DeeperUserEngagement.voiceNotes,
        hideStickersButton: !DeeperUserEngagement.stickers,
        hideTakePhotoOption: !CoreMessagingExperience.photosSharing,
        hideImageAttachmentOption: !CoreMessagingExperience.photosSharing,
        hideVideoAttachmentOption: !CoreMessagingExperience.videoSharing,
        hideAudioAttachmentOption: !CoreMessagingExperience.audioSharing,
        hideFileAttachmentOption: !CoreMessagingExperience.fileSharing,
        hideAttachmentButton: !(CoreMessagingExperience.photosSharing ||
            CoreMessagingExperience.videoSharing ||
            CoreMessagingExperience.audioSharing ||
            CoreMessagingExperience.fileSharing),
      );
    }
  }

  Widget _buildBlockedUserSection(CometChatThreadController controller) {
    return Container(
      padding: EdgeInsets.symmetric(
        vertical: spacing.padding2 ?? 8,
        horizontal: spacing.padding5 ?? 20,
      ),
      color: colorPalette.background4,
      child: Column(
        children: [
          Padding(
            padding: EdgeInsets.only(bottom: spacing.padding1 ?? 0),
            child: Text(
              cc.Translations.of(context).cantSendMessageBlockedUser,
              style: TextStyle(
                color: colorPalette.textSecondary,
                fontSize: typography.body?.regular?.fontSize,
                fontWeight: typography.body?.regular?.fontWeight,
                fontFamily: typography.body?.regular?.fontFamily,
              ),
            ),
          ),
          controller.isBlockLoading.value
              ? Center(
                  child: CircularProgressIndicator(
                    color: colorPalette.background2,
                  ),
                )
              : SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: () => controller.unBlockUser(),
                    style: ElevatedButton.styleFrom(
                      backgroundColor:
                          colorPalette.transparent, // Set proper color
                      elevation: 0,
                      shape: RoundedRectangleBorder(
                        borderRadius:
                            BorderRadius.circular(spacing.radius2 ?? 0),
                        side: BorderSide(
                          color: colorPalette.borderDark ?? Colors.transparent,
                          width: 1,
                        ),
                      ),
                    ),
                    child: Text(
                      cc.Translations.of(context).unBlock,
                      style: TextStyle(
                        color: colorPalette.textPrimary,
                        fontSize: typography.caption1?.regular?.fontSize,
                        fontWeight: typography.caption1?.regular?.fontWeight,
                        fontFamily: typography.caption1?.regular?.fontFamily,
                      ),
                    ),
                  ),
                ),
        ],
      ),
    );
  }

  Widget _buildKickedFromGroup(CometChatThreadController controller) {
    return Container(
      padding: EdgeInsets.symmetric(
        vertical: spacing.padding2 ?? 8,
        horizontal: spacing.padding5 ?? 20,
      ),
      color: colorPalette.background4,
      child: Padding(
        padding: EdgeInsets.only(bottom: spacing.padding1 ?? 0),
        child: Text(
          cc.Translations.of(context).cantSendMessageNotMember,
          style: TextStyle(
            color: colorPalette.textSecondary,
            fontSize: typography.body?.regular?.fontSize,
            fontWeight: typography.body?.regular?.fontWeight,
            fontFamily: typography.body?.regular?.fontFamily,
          ),
        ),
      ),
    );
  }
}
