import 'package:chat_builder/messages/messages.dart';
import 'package:cometchat_calls_uikit/cometchat_calls_uikit.dart';
import 'package:cometchat_chat_uikit/cometchat_chat_uikit.dart';
import 'package:flutter/material.dart';
import 'package:chat_builder/builder/builder_settings.dart';
import 'package:chat_builder/guard_screen.dart';

class ChatBuilder {

  static MaterialApp createApp() {
    return MaterialApp(
      theme: ThemeData(
        fontFamily: BuilderTypography.font,
        extensions: [
          CometChatColorPalette(
            textPrimary: BuilderColor.primaryTextLight,
            textSecondary: BuilderColor.secondaryTextLight,
            primary: BuilderColor.brandColor,
          ),
        ],
        appBarTheme: AppBarTheme(
          scrolledUnderElevation: 0.0,
        ),
      ),
      darkTheme: ThemeData(
        fontFamily: BuilderTypography.font,
        extensions: [
          CometChatColorPalette(
            textPrimary: BuilderColor.primaryTextDark,
            textSecondary: BuilderColor.secondaryTextDark,
            primary: BuilderColor.brandColor,
          ),
        ],
        appBarTheme: AppBarTheme(
          scrolledUnderElevation: 0.0,
        ),
      ),
      title: 'CometChat Builder',
      navigatorKey: CallNavigationContext.navigatorKey,
      home: const GuardScreen(),
      debugShowCheckedModeBanner: false,
    );
  }

  static void launchBuilder(BuildContext context) {
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (context) => createApp(),
      ),
    );
  }

  static void launchMessages(
      {User? user, Group? group, required BuildContext context}) {
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (context) => createMessagesApp(
          context: context,
          user: user,
          group: group,
        ),
      ),
    );
  }

  static MaterialApp createMessagesApp({
    required BuildContext context,
    User? user,
    Group? group,
  }) {
    return MaterialApp(
      theme: ThemeData(
        fontFamily: BuilderTypography.font,
        extensions: [
          CometChatColorPalette(
            textPrimary: BuilderColor.primaryTextLight,
            textSecondary: BuilderColor.secondaryTextLight,
            primary: BuilderColor.brandColor,
          ),
        ],
        appBarTheme: AppBarTheme(scrolledUnderElevation: 0.0),
      ),
      darkTheme: ThemeData(
        fontFamily: BuilderTypography.font,
        extensions: [
          CometChatColorPalette(
            textPrimary: BuilderColor.primaryTextDark,
            textSecondary: BuilderColor.secondaryTextDark,
            primary: BuilderColor.brandColor,
          ),
        ],
        appBarTheme: AppBarTheme(scrolledUnderElevation: 0.0),
      ),
      title: 'CometChat Builder',
      navigatorKey: CallNavigationContext.navigatorKey,
      home: MessagesSample(user: user, group: group),
      debugShowCheckedModeBanner: false,
    );
  }

}