import 'dart:io';

class DemoMetaInfoConstants {
  static String name = "chat_builder";
  static String type = "chat_builder";
  static String version = "5.2.6";
  static String bundle = Platform.isAndroid
      ? "com.cometchat.sampleapp.flutter.android"
      : "com.cometchat.sampleapp.flutter.ios";
  static String platform = "Flutter";
}
