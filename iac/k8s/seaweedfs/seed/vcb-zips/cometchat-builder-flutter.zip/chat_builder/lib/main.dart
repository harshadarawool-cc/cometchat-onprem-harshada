import 'dart:async';
import 'package:chat_builder/builder/chat_builder.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:chat_builder/builder/builder_settings_helper.dart';
import 'package:chat_builder/utils/page_manager.dart';
import 'prefs/shared_preferences.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await BuilderSettingsHelper.loadFromAsset();
  SharedPreferencesClass.init();
  Get.put(PageManager());

  runApp(const CometChatBuilder());
}

class CometChatBuilder extends StatefulWidget {
  const CometChatBuilder({super.key});

  @override
  State<CometChatBuilder> createState() => _CometChatBuilderState();
}

class _CometChatBuilderState extends State<CometChatBuilder> {
  @override
  Widget build(BuildContext context) {
    return ChatBuilder.createApp();
  }
}
