import 'package:flutter/material.dart';
import 'package:cometchat_chat_uikit/cometchat_chat_uikit.dart';
import 'package:cometchat_chat_uikit/cometchat_chat_uikit.dart' as cc;
import 'package:get/get.dart';
import 'package:chat_builder/builder/builder_settings.dart';
import 'package:chat_builder/thread_screen/cometchat_thread.dart';
import 'package:chat_builder/user_info/cometchat_user_info.dart';
import '../group_info/cometchat_group_info.dart';
import '../utils/page_manager.dart';
import 'messages_controller.dart';

class MessagesSample extends StatefulWidget {
  final User? user;
  final Group? group;
  final BaseMessage? parentMessage;
  final bool? isHistory;
  final BaseMessage? message;

  const MessagesSample(
      {Key? key, this.user, this.group, this.parentMessage, this.isHistory, this.message})
      : super(key: key);

  @override
  State<MessagesSample> createState() => _MessagesSampleState();
}

class _MessagesSampleState extends State<MessagesSample> {
  late CometChatMessagesController messagesController;

  late CometChatColorPalette colorPalette;
  late CometChatTypography typography;
  late CometChatSpacing spacing;

  @override
  void initState() {
    super.initState();
    messagesController = CometChatMessagesController(widget.user, widget.group);
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    typography = CometChatThemeHelper.getTypography(context);
    colorPalette = CometChatThemeHelper.getColorPalette(context);
    spacing = CometChatThemeHelper.getSpacing(context);
  }

  CometChatMentionsFormatter getMentionsTap() {
    CometChatMentionsFormatter mentionsFormatter;
    return mentionsFormatter = CometChatMentionsFormatter(
      user: widget.user,
      group: widget.group,
      onMentionTap: (mention, mentionedUser, {message}) {
        if (mentionedUser.uid != CometChatUIKit.loggedInUser!.uid) {
          PageManager().navigateToMessages(
            context: context,
            user: mentionedUser,
          );
        }
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final ccColor = CometChatThemeHelper.getColorPalette(context);
    return GetBuilder<CometChatMessagesController>(
      init: messagesController,
      tag: messagesController.tag,
      builder: (controller) {
        return Scaffold(
          backgroundColor: ccColor.background1,
          appBar: CometChatMessageHeader(
            user: widget.user,
            group: widget.group,
            usersStatusVisibility:
                CoreMessagingExperience.userAndFriendsPresence,
            messageHeaderStyle: CometChatMessageHeaderStyle(
                backgroundColor:
                    (controller.isUserAgentic()) ? ccColor.background1 : null,
                border: (controller.isUserAgentic())
                    ? Border(
                        bottom: BorderSide(
                          color: ccColor.borderLight ?? Colors.transparent,
                          width: 1.0,
                        ),
                      )
                    : null,
                statusIndicatorStyle: CometChatStatusIndicatorStyle(
                  backgroundColor: colorPalette.transparent,
                  borderRadius: BorderRadius.zero,
                  border: Border.all(
                    width: 0,
                    color: colorPalette.transparent ?? Colors.transparent,
                  ),
                )),
            hideVideoCallButton: widget.user != null
                ? (controller.user?.blockedByMe == true ||
                    controller.isUserAgentic() ||
                    !VoiceAndVideoCalling.oneOnOneVideoCalling)
                : widget.group != null
                    ? (controller.group?.hasJoined == false ||
                        controller.group?.isBannedFromGroup == true ||
                        !VoiceAndVideoCalling.groupVideoConference)
                    : false,
            hideVoiceCallButton: widget.user != null
                ? (controller.user?.blockedByMe == true ||
                    controller.isUserAgentic() ||
                    !VoiceAndVideoCalling.oneOnOneVoiceCalling)
                : widget.group != null
                    ? (controller.group?.hasJoined == false ||
                        controller.group?.isBannedFromGroup == true ||
                        !VoiceAndVideoCalling.groupVoiceConference)
                    : false,
            onBack: () {
              FocusManager.instance.primaryFocus?.unfocus();
              Navigator.of(context).pop();
            },
            options: (user, group, context) {
              return [
                if (controller.user != null &&
                    DeeperUserEngagement.userInfo &&
                    ((controller.user?.role == AIConstants.aiRole) ||
                        (controller.user?.blockedByMe != null &&
                            controller.user?.blockedByMe! == false)))
                  CometChatOption(
                    id: 'user-info',
                    title: cc.Translations.of(context).userInfo,
                    iconWidget: Padding(
                      padding: EdgeInsets.only(right: spacing.padding2 ?? 0),
                      child: Icon(
                        Icons.info_outline,
                        color: ccColor.iconSecondary,
                        size: 24,
                      ),
                    ),
                    onClick: () {
                      if (controller.user != null) {
                        FocusManager.instance.primaryFocus?.unfocus();
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) =>
                                CometchatUserInfo(user: controller.user!),
                          ),
                        );
                      }
                    },
                  ),
                if (controller.group != null &&
                    DeeperUserEngagement.groupInfo &&
                    (controller.group?.hasJoined == true ||
                        controller.group?.isBannedFromGroup == false))
                  CometChatOption(
                    id: 'group-info',
                    title: cc.Translations.of(context).groupInfo,
                    iconWidget: Padding(
                      padding: EdgeInsets.only(right: spacing.padding2 ?? 0),
                      child: Icon(
                        Icons.info_outline,
                        color: ccColor.iconSecondary,
                        size: 24,
                      ),
                    ),
                    onClick: () {
                      if (controller.group != null) {
                        FocusManager.instance.primaryFocus?.unfocus();
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) =>
                                CometchatGroupInfo(group: controller.group!),
                          ),
                        );
                      }
                    },
                  ),
                if(CoreMessagingExperience.conversationAndAdvancedSearch)
                CometChatOption(
                  id: 'search',
                  title: cc.Translations.of(context).search,
                  iconWidget: Padding(
                    padding: EdgeInsets.only(right: spacing.padding2 ?? 0),
                    child: Icon(
                      Icons.search,
                      color: ccColor.iconSecondary,
                      size: 24,
                    ),
                  ),
                  onClick: () {
                    Navigator.of(context).push(
                      MaterialPageRoute(
                        builder: (context) => CometChatSearch(
                          user: controller.user,
                          group: controller.group,
                          onBack: () {
                            Navigator.of(context).pop();
                          },
                          onMessageClicked: (message) {
                            User? user;
                            Group? group;
                            if (message.receiverType ==
                                ReceiverTypeConstants.user) {
                              user = (message.sender?.uid ==
                                  CometChatUIKit.loggedInUser?.uid)
                                  ? message.receiver as User?
                                  : message.sender;
                            } else {
                              group = message.receiver as Group?;
                            }
                            if (message.parentMessageId > 0) {
                              CometChatHelper.getMessageDetails(
                                message.parentMessageId,
                                onSuccess: (getMessage) {
                                  if (getMessage == null) {
                                    SnackBarUtils.show(
                                      cc.Translations.of(context)
                                          .somethingWentWrongError,
                                      context,
                                      snackBarConfiguration:
                                      cc.SnackBarConfiguration(
                                        backgroundColor: colorPalette.error,
                                      ),
                                    );
                                  } else {
                                    User? threadUser;
                                    Group? threadGroup;
                                    if (message.receiverType ==
                                        ReceiverTypeConstants.user) {
                                      threadUser = (getMessage.sender?.uid ==
                                          CometChatUIKit.loggedInUser?.uid)
                                          ? getMessage.receiver as User?
                                          : getMessage.sender;
                                    } else {
                                      threadGroup =
                                      getMessage.receiver as Group?;
                                    }
                                    Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                        builder: (context) => CometChatThread(
                                          user: threadUser,
                                          group: threadGroup,
                                          message: getMessage,
                                          messageId: message.id,
                                        ),
                                      ),
                                    );
                                  }
                                },
                                onError: (excep) {
                                  SnackBarUtils.show(
                                    cc.Translations.of(context)
                                        .somethingWentWrongError,
                                    context,
                                    snackBarConfiguration:
                                    cc.SnackBarConfiguration(
                                      backgroundColor: colorPalette.error,
                                    ),
                                  );
                                },
                              );
                            } else {
                              Navigator.pushReplacement(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => MessagesSample(
                                    user: user,
                                    group: group,
                                    message: message,
                                  ),
                                ),
                              );
                            }
                          },
                          searchIn: [SearchScope.messages],
                        ),
                      ),
                    );
                  },
                ),
                CometChatOption(
                  id: 'conversation-summary',
                  title: cc.Translations.of(context).conversationSummary,
                  iconWidget: Padding(
                    padding: EdgeInsets.only(right: spacing.padding2 ?? 0),
                    child: Image.asset(
                      AssetConstants.conversationSummaryOutlined,
                      color: ccColor.iconSecondary,
                      package: UIConstants.packageName,
                      height: 24,
                      width: 24,
                    ),
                  ),
                  onClick: () {
                    FocusManager.instance.primaryFocus?.unfocus();
                    controller.updateConversationsSummarySetting(true);
                    print(
                        "Conversation Summary Clicked ${controller.generateConversationSummary}");
                  },
                ),
              ];
            },
            chatHistoryButtonClick: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => CometChatAIAssistantChatHistory(
                    user: widget.user,
                    group: widget.group,
                    onNewChatButtonClicked: () {
                      onNewChatClicked(true);
                    },
                    onMessageClicked: (message) {
                      if (message != null) {
                        Navigator.of(context)
                          ..pop()
                          ..pop();
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => MessagesSample(
                              user: widget.user,
                              group: widget.group,
                              parentMessage: message,
                              isHistory: true,
                            ),
                          ),
                        );
                      }
                    },
                    onClose: () {
                      Navigator.of(context).pop();
                    },
                  ),
                ),
              );
            },
            newChatButtonClick: () {
              onNewChatClicked(false);
            },
          ),
          resizeToAvoidBottomInset: true,
          body: Container(
            color: ccColor.background3,
            child: SafeArea(
              top: false,
              child: Column(
                children: [
                  Expanded(
                    child: GestureDetector(
                      onTap: () => FocusScope.of(context).unfocus(),
                      child: getMessageList(
                        user: widget.user,
                        group: widget.group,
                        context: context,
                        parentMessage: widget.parentMessage,
                        controller: controller,
                      ),
                    ),
                  ),
                  getComposer(controller),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Widget getComposer(CometChatMessagesController controller) {
    bool agentic = controller.isUserAgentic();
    if (controller.user != null &&
        controller.user?.blockedByMe != null &&
        controller.user?.blockedByMe! == true) {
      return _buildBlockedUserSection(controller);
    } else if (controller.group != null &&
        (controller.group?.hasJoined == false ||
            controller.group?.isBannedFromGroup == true)) {
      return _buildKickedFromGroup(controller);
    } else if (Layout.compactMessageComposer && !agentic) {
      return CometChatCompactMessageComposer(
        user: widget.user,
        group: widget.group,
        textFormatters: [getMentionsTap()],
        disableMentions:
        agentic ? true : !DeeperUserEngagement.mentions,
        disableMentionAll: !DeeperUserEngagement.mentionAll,
        placeholderText: (agentic)
            ? "${cc.Translations.of(context).askAnything}..."
            : null,
        parentMessageId: widget.parentMessage?.id ?? 0,
        compactMessageComposerStyle: CometChatCompactMessageComposerStyle(
          backgroundColor: agentic ? colorPalette.background1 : null,
        ),
        disableTypingEvents: !CoreMessagingExperience.typingIndicator,
        hidePollsOption: !DeeperUserEngagement.polls,
        hideCollaborativeWhiteboardOption:
        !DeeperUserEngagement.collaborativeWhiteboard,
        hideCollaborativeDocumentOption:
        !DeeperUserEngagement.collaborativeDocument,
        hideVoiceRecordingButton: agentic ? true : !DeeperUserEngagement.voiceNotes,
        hideStickersButton: agentic ? true : !DeeperUserEngagement.stickers,
        hideTakePhotoOption: !CoreMessagingExperience.photosSharing,
        hideImageAttachmentOption: !CoreMessagingExperience.photosSharing,
        hideVideoAttachmentOption: !CoreMessagingExperience.videoSharing,
        hideAudioAttachmentOption: !CoreMessagingExperience.audioSharing,
        hideFileAttachmentOption: !CoreMessagingExperience.fileSharing,
        hideAttachmentButton: agentic ? true : !(CoreMessagingExperience.photosSharing ||
            CoreMessagingExperience.videoSharing ||
            CoreMessagingExperience.audioSharing ||
            CoreMessagingExperience.fileSharing ||
            DeeperUserEngagement.polls ||
            DeeperUserEngagement.collaborativeWhiteboard ||
            DeeperUserEngagement.collaborativeDocument),
      );
    } else {
      return CometChatMessageComposer(
        user: widget.user,
        group: widget.group,
        disableMentions:
            controller.isUserAgentic() ? true : !DeeperUserEngagement.mentions,
        disableMentionAll: !DeeperUserEngagement.mentionAll,
        placeholderText: (controller.isUserAgentic())
            ? "${cc.Translations.of(context).askAnything}..."
            : null,
        parentMessageId: widget.parentMessage?.id ?? 0,
        messageComposerStyle: CometChatMessageComposerStyle(
          dividerColor: agentic ? Colors.transparent : null,
          dividerHeight: agentic ? 0 : null,
          backgroundColor: agentic ? colorPalette.background1 : null,
        ),
        disableTypingEvents: !CoreMessagingExperience.typingIndicator,
        hidePollsOption: !DeeperUserEngagement.polls,
        hideCollaborativeWhiteboardOption:
            !DeeperUserEngagement.collaborativeWhiteboard,
        hideCollaborativeDocumentOption:
            !DeeperUserEngagement.collaborativeDocument,
        hideVoiceRecordingButton: !DeeperUserEngagement.voiceNotes,
        hideStickersButton: !DeeperUserEngagement.stickers,
        hideTakePhotoOption: !CoreMessagingExperience.photosSharing,
        hideImageAttachmentOption: !CoreMessagingExperience.photosSharing,
        hideVideoAttachmentOption: !CoreMessagingExperience.videoSharing,
        hideAudioAttachmentOption: !CoreMessagingExperience.audioSharing,
        hideFileAttachmentOption: !CoreMessagingExperience.fileSharing,
        hideAttachmentButton: !(CoreMessagingExperience.photosSharing ||
            CoreMessagingExperience.videoSharing ||
            CoreMessagingExperience.audioSharing ||
            CoreMessagingExperience.fileSharing ||
            DeeperUserEngagement.polls ||
            DeeperUserEngagement.collaborativeWhiteboard ||
            DeeperUserEngagement.collaborativeDocument),
      );
    }
  }

  Widget _buildBlockedUserSection(CometChatMessagesController controller) {
    return Container(
      padding: EdgeInsets.symmetric(
        vertical: spacing.padding2 ?? 8,
        horizontal: spacing.padding5 ?? 20,
      ),
      color: colorPalette.background4,
      child: Column(
        children: [
          Padding(
            padding: EdgeInsets.only(bottom: spacing.padding1 ?? 0),
            child: Text(
              cc.Translations.of(context).cantSendMessageBlockedUser,
              style: TextStyle(
                color: colorPalette.textSecondary,
                fontSize: typography.body?.regular?.fontSize,
                fontWeight: typography.body?.regular?.fontWeight,
                fontFamily: typography.body?.regular?.fontFamily,
              ),
            ),
          ),
          controller.isBlockLoading.value
              ? Center(
                  child: CircularProgressIndicator(
                    color: colorPalette.background2,
                  ),
                )
              : SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: () => controller.unBlockUser(),
                    style: ElevatedButton.styleFrom(
                      backgroundColor:
                          colorPalette.transparent, // Set proper color
                      elevation: 0,
                      shape: RoundedRectangleBorder(
                        borderRadius:
                            BorderRadius.circular(spacing.radius2 ?? 0),
                        side: BorderSide(
                          color: colorPalette.borderDark ?? Colors.transparent,
                          width: 1,
                        ),
                      ),
                    ),
                    child: Text(
                      cc.Translations.of(context).unBlock,
                      style: TextStyle(
                        color: colorPalette.textPrimary,
                        fontSize: typography.caption1?.regular?.fontSize,
                        fontWeight: typography.caption1?.regular?.fontWeight,
                        fontFamily: typography.caption1?.regular?.fontFamily,
                      ),
                    ),
                  ),
                ),
        ],
      ),
    );
  }

  Widget _buildKickedFromGroup(CometChatMessagesController controller) {
    return Container(
      padding: EdgeInsets.symmetric(
        vertical: spacing.padding2 ?? 8,
        horizontal: spacing.padding5 ?? 20,
      ),
      color: colorPalette.background4,
      child: Padding(
        padding: EdgeInsets.only(bottom: spacing.padding1 ?? 0),
        child: Text(
          cc.Translations.of(context).cantSendMessageNotMember,
          style: TextStyle(
            color: colorPalette.textSecondary,
            fontSize: typography.body?.regular?.fontSize,
            fontWeight: typography.body?.regular?.fontWeight,
            fontFamily: typography.body?.regular?.fontFamily,
          ),
        ),
      ),
    );
  }

  onNewChatClicked(bool isHistory) async {
    if (isHistory) {
      Navigator.of(context).pop();
    }

    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (context) => MessagesSample(
          user: widget.user,
          group: widget.group,
        ),
      ),
    );
  }

  Widget getMessageList({
    User? user,
    Group? group,
    context,
    BaseMessage? parentMessage,
    required CometChatMessagesController controller,
  }) {
    MessagesRequestBuilder? requestBuilder = MessagesRequestBuilder();

    if (widget.isHistory != null &&
        widget.isHistory == true &&
        parentMessage != null &&
        controller.isUserAgentic()) {
      requestBuilder = MessagesRequestBuilder()
        ..parentMessageId = parentMessage.id
        ..withParent = true
        ..hideReplies = true;
    }

    return CometChatMessageList(
      showMarkAsUnreadOption: CoreMessagingExperience.markAsUnread,
      startFromUnreadMessages: CoreMessagingExperience.markAsUnread,
      user: user,
      group: group,
      messageId: widget.message?.id,
      textFormatters: [
        CometChatEmailFormatter(),
        CometChatPhoneNumberFormatter(),
        CometChatUrlFormatter(),
        getMentionsTap(),
        CometChatUrlFormatter(),
        CometChatEmailFormatter(),
        CometChatPhoneNumberFormatter(),
      ],
      onThreadRepliesClick: (message, context, {template}) {
        if (CoreMessagingExperience.threadConversationAndReplies)
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => CometChatThread(
                user: user,
                group: group,
                message: message,
                template: template,
              ),
            ),
          );
      },
      hideEditMessageOption: !CoreMessagingExperience.editMessage,
      hideDeleteMessageOption: !CoreMessagingExperience.deleteMessage,
      receiptsVisibility:
          CoreMessagingExperience.messageDeliveryAndReadReceipts,
      hideReactionOption: !DeeperUserEngagement.reactions,
      hideTranslateMessageOption: !DeeperUserEngagement.messageTranslation,
      enableConversationStarters: AiUserCopilot.conversationStarter,
      enableSmartReplies: AiUserCopilot.smartReply,
      hideMessagePrivatelyOption:
          !PrivateMessagingWithinGroups.sendPrivateMessageToGroupMembers,
      hideMessageInfoOption:
          !CoreMessagingExperience.messageDeliveryAndReadReceipts,
      hideReplyInThreadOption: (controller.isUserAgentic())
          ? true
          : !CoreMessagingExperience.threadConversationAndReplies,
      hideThreadView: controller.isUserAgentic() ? true : false,
      hideFlagOption: !ModeratorControls.reportMessage,
      hideReplyOption: !CoreMessagingExperience.quotedReplies,
      messagesRequestBuilder:(widget.isHistory != null &&
          widget.isHistory == true &&
          parentMessage != null &&
          controller.isUserAgentic()) ? requestBuilder : null,
        style: CometChatMessageListStyle(
          backgroundColor:
          (controller.isUserAgentic()) ? colorPalette.background3 : null,
          outgoingMessageBubbleStyle: CometChatOutgoingMessageBubbleStyle(
            textBubbleStyle: CometChatTextBubbleStyle(
              backgroundColor:
              (controller.isUserAgentic()) ? colorPalette.background4 : null,
              textColor:
              (controller.isUserAgentic()) ? colorPalette.textPrimary : null,
              messageBubbleDateStyle: CometChatDateStyle(
                textColor:
                (controller.isUserAgentic()) ? colorPalette.neutral600 : null,
              ),
            ),
            messageBubbleDateStyle: CometChatDateStyle(
              textColor:
              (controller.isUserAgentic()) ? colorPalette.textPrimary : null,
            ),
          ),
        ),
    );
  }
}
