export interface CometChatSettingsInterface {
  chatFeatures: {
    coreMessagingExperience: {
      typingIndicator: boolean;
      threadConversationAndReplies: boolean;
      photosSharing: boolean;
      videoSharing: boolean;
      audioSharing: boolean;
      fileSharing: boolean;
      editMessage: boolean;
      deleteMessage: boolean;
      messageDeliveryAndReadReceipts: boolean;
      userAndFriendsPresence: boolean;
      conversationAndAdvancedSearch?: boolean;
      moderation?: boolean;
      quotedReplies?: boolean;
      markAsUnread?: boolean;
      richTextFormatting?: boolean;
    };
    deeperUserEngagement: {
      mentions: boolean;
      mentionAll?: boolean;
      reactions: boolean;
      messageTranslation: boolean;
      polls: boolean;
      collaborativeWhiteboard: boolean;
      collaborativeDocument: boolean;
      voiceNotes: boolean;
      emojis: boolean;
      stickers: boolean;
      userInfo: boolean;
      groupInfo: boolean;
    };
    aiUserCopilot: {
      conversationStarter: boolean;
      conversationSummary: boolean;
      smartReply: boolean;
    };
    userManagement?: {
      friendsOnly?: boolean;
    };
    groupManagement: {
      createGroup: boolean;
      addMembersToGroups: boolean;
      joinLeaveGroup: boolean;
      deleteGroup: boolean;
      viewGroupMembers: boolean;
    };
    moderatorControls: {
      kickUsers: boolean;
      banUsers: boolean;
      promoteDemoteMembers: boolean;
      reportMessage?: boolean;
    };
    privateMessagingWithinGroups: {
      sendPrivateMessageToGroupMembers: boolean;
    };
    inAppSounds: {
      incomingMessageSound?: boolean;
      outgoingMessageSound?: boolean;
    };
  };
  callFeatures: {
    voiceAndVideoCalling: {
      oneOnOneVoiceCalling: boolean;
      oneOnOneVideoCalling: boolean;
      groupVideoConference: boolean;
      groupVoiceConference: boolean;
    };
  };
  layout: {
    withSideBar: boolean;
    tabs: string[];
    chatType: string;
    compactMessageComposer?: boolean;
  };
  style: {
    theme: string;
    color: {
      brandColor: string;
      primaryTextLight: string;
      primaryTextDark: string;
      secondaryTextLight: string;
      secondaryTextDark: string;
    };
    typography: {
      font: string;
      size: string;
    };
  };
  noCode?: {
    docked: boolean;
    styles: {
      buttonBackGround: string;
      buttonShape: string;
      openIcon: string;
      closeIcon: string;
      customJs: string;
      customCss: string;
      dockedAlignment?: string;
    };
  };
  agent?: {
    chatHistory: boolean;
    newChat: boolean;
    agentIcon: string;
    showAgentIcon: boolean;
  };
}

export const CometChatSettings: CometChatSettingsInterface = {
  chatFeatures: {
    coreMessagingExperience: {
      typingIndicator: true,
      threadConversationAndReplies: true,
      photosSharing: true,
      videoSharing: true,
      audioSharing: true,
      fileSharing: true,
      editMessage: true,
      deleteMessage: true,
      messageDeliveryAndReadReceipts: true,
      userAndFriendsPresence: true,
      conversationAndAdvancedSearch: true,
      moderation: true,
      quotedReplies: false,
      markAsUnread: false,
      richTextFormatting: true,
    },
    deeperUserEngagement: {
      mentions: true,
      mentionAll: true,
      reactions: true,
      messageTranslation: true,
      polls: true,
      collaborativeWhiteboard: true,
      collaborativeDocument: true,
      voiceNotes: true,
      emojis: true,
      stickers: true,
      userInfo: true,
      groupInfo: true,
    },
    aiUserCopilot: {
      conversationStarter: false,
      conversationSummary: false,
      smartReply: false,
    },
    userManagement: {
      friendsOnly: false,
    },
    groupManagement: {
      createGroup: true,
      addMembersToGroups: true,
      joinLeaveGroup: true,
      deleteGroup: true,
      viewGroupMembers: true,
    },
    moderatorControls: {
      kickUsers: true,
      banUsers: true,
      promoteDemoteMembers: true,
      reportMessage: true,
    },
    privateMessagingWithinGroups: {
      sendPrivateMessageToGroupMembers: true,
    },
    inAppSounds: {
      incomingMessageSound: true,
      outgoingMessageSound: true,
    },
  },
  callFeatures: {
    voiceAndVideoCalling: {
      oneOnOneVoiceCalling: true,
      oneOnOneVideoCalling: true,
      groupVideoConference: true,
      groupVoiceConference: true,
    },
  },
  layout: {
    withSideBar: true,
    tabs: ['chats', 'calls', 'users', 'groups'],
    chatType: 'user',
    compactMessageComposer: false,
  },

  style: {
    theme: 'system',
    color: {
      brandColor: '#6852D6',
      primaryTextLight: '#141414',
      primaryTextDark: '#FFFFFF',
      secondaryTextLight: '#727272',
      secondaryTextDark: '#989898',
    },
    typography: {
      font: 'roboto',
      size: 'default',
    },
  },
  noCode: {
    docked: false,
    styles: {
      buttonBackGround: '#141414',
      buttonShape: 'rounded',
      openIcon: 'https://cdn.jsdelivr.net/npm/@cometchat/chat-embed@latest/dist/icons/docked_open_icon.svg',
      closeIcon: 'https://cdn.jsdelivr.net/npm/@cometchat/chat-embed@latest/dist/icons/docked_close_icon.svg',
      customJs: `// Write your JavaScript here\nconsole.log("Hello World!");`,
      customCss: `/* Write your CSS here */\nbody { background-color: #fff; }`,
      dockedAlignment: 'right', // 'left' or 'right'
    },
  },
  agent: {
    chatHistory: true,
    newChat: true,
    agentIcon: '',
    showAgentIcon: true,
  },
};
