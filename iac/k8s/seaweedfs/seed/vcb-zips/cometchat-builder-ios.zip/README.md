
<p align="center">
  <img alt="CometChat" src="https://assets.cometchat.io/website/images/logos/banner.png">
</p>

# CometChat iOS UI Kit (with Visual Chat Builder)

The CometChat iOS UI Kit provides a pre-built user interface that developers can use to quickly integrate a reliable & fully-featured chat experience into an existing or new iOS app using **Visual Chat Builder (VCB)** configuration.

---
## 🔧 Prerequisites

Before running this project on iOS, make sure you have:

- Xcode  
- macOS device with macOS 12.0 or above  
- iOS Device or Simulator with iOS 13.0 or above  
- CocoaPods (latest version installed)  
- Internet connection (required for CometChat services)  

## 🚀 Setup

1. Download the project zip from the CometChat Dashboard and extract it.
2. Navigate to the project folder
   ```bash
    cd <project-folder>
   ```
3. Open the .xcodeproj file once to let Xcode configure the project.
4. Install dependencies using CocoaPods
   ```bash
   pod install
   ```
5. Open the .xcworkspace file instead of .xcodeproj from now on
open <ProjectName>.xcworkspace

6. Build & run the project in Xcode.


## 📦 Installation (CometChatBuilder)

### 🚀 CocoaPods

```ruby
pod 'CometChatBuilder'
```

Then run:

```bash
pod install
```

---

### 📦 Swift Package Manager (SPM)

1. Open your Xcode project.
2. Go to **File → Add Packages**.
3. Enter the URL of your Git repository (or local path) where `CometChatBuilder` code is hosted.
4. Select the `CometChatBuilder` package and add it to your app target.

---

## 🎯 Integration Options

The Visual Chat Builder (VCB) configuration can be loaded into your app using a local JSON file.

---

### Load from JSON

Use this method if you are shipping a `.json` configuration file with your app.

#### 📁 Step 1: Add your JSON file

Place your `cometchat-builder-settings.json` inside your app target and make sure:

- It's added to your target membership.

#### 🧠 Step 2: Load Settings at Launch

```swift
import CometChatBuilder

func application(_ application: UIApplication,
                 didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {

    // This automatically loads JSON config
    CometChatBuilderSettings.loadFromJSON()

    CometChatTheme.primaryColor = UIColor.dynamicColor(
            lightModeColor: UIColor(hex: CometChatBuilderSettings.shared.style.color.brandColor),
            darkModeColor: UIColor(hex: CometChatBuilderSettings.shared.style.color.brandColor)
        )
        
        CometChatTheme.textColorPrimary = UIColor.dynamicColor(
            lightModeColor: UIColor(hex: CometChatBuilderSettings.shared.style.color.primaryTextLight),
            darkModeColor: UIColor(hex: CometChatBuilderSettings.shared.style.color.primaryTextDark)
        )
        
        CometChatTheme.textColorSecondary = UIColor.dynamicColor(
            lightModeColor: UIColor(hex: CometChatBuilderSettings.shared.style.color.secondaryTextLight),
            darkModeColor: UIColor(hex: CometChatBuilderSettings.shared.style.color.secondaryTextDark)
        )
        
        CometChatTypography.customFontFamilyName = CometChatBuilderSettings.shared.style.typography.font

    return true
}
```
---

## 🔧 VCB Settings Categories

Your VCB configuration supports:

- **💬 Core Messaging Experience** – Typing, media sharing, replies, etc.
- **🎯 Deeper User Engagement** – Reactions, mentions, translation, polls
- **🤖 AI User Copilot** – Smart replies, summaries, starters
- **👥 Group Management** – Create/delete group, add members
- **🛡️ Moderator Controls** – Ban/kick/promote members
- **📞 Voice & Video Calling** – 1:1 and group calling support
- **🎨 Layout & Styling** – Theme, typography, layout mode

---

## 🛠 Troubleshooting

- Ensure your QR code is valid and generated from the official builder.
- Confirm `cometchat-builder-settings.json` is added to the app bundle.
- Network errors will fallback to user alerts.
- For SPM: make sure resources (images) are in `CometChatBuilder.bundle`.

---

## 📚 Resources

- 📖 [CometChat UIKit iOS Docs](https://www.cometchat.com/docs/ios-uikit/overview)
- 💬 [CometChat Dashboard](https://app.cometchat.com/)
- 🎫 [Create Support Ticket](https://help.cometchat.com/hc/en-us)

---
