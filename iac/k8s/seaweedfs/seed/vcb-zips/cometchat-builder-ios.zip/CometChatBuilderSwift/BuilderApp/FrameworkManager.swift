//
//  FrameworkManager.swift
//  BuilderApp
//
//  Created by Dawinder on 25/08/25.
//

import Foundation
import UIKit
import CometChatUIKitSwift
import CometChatSDK
import CometChatBuilder

public class FrameworkManager {
    
    public static var currentScene: UIScene?
    public static var window: UIWindow?
    
    public static func initialize(with scene: UIScene, completion: @escaping () -> Void) {
        currentScene = scene
        
        // load settings
        CometChatBuilderSettings.loadFromJSON()
        
        applyTheme()
        
        initialiseCometChatUIKit {
            if CometChat.getLoggedInUser() != nil {
                if UIDevice.current.userInterfaceIdiom == .pad {
                    setRootViewController(SplitViewController())
                } else {
                    setRootViewController(UINavigationController(rootViewController: HomeScreenViewController()))
                }
            } else {
                if AppConstants.APP_ID.isEmpty || AppConstants.AUTH_KEY.isEmpty || AppConstants.REGION.isEmpty {
                    setRootViewController(ChangeAppCredentialsVC())
                } else {
                    setRootViewController(LoginWithUidVC())
                }
            }
            completion()
        }
    }
    
    public static func applyTheme() {
        CometChatTheme.primaryColor = UIColor.dynamicColor(
            lightModeColor: UIColor(hex: CometChatBuilderSettings.shared.style.color.brandColor),
            darkModeColor: UIColor(hex: CometChatBuilderSettings.shared.style.color.brandColor)
        )
        
        CometChatTheme.textColorPrimary = UIColor.dynamicColor(
            lightModeColor: UIColor(hex: CometChatBuilderSettings.shared.style.color.primaryTextLight),
            darkModeColor: UIColor(hex: CometChatBuilderSettings.shared.style.color.primaryTextDark)
        )
        
        CometChatTheme.textColorSecondary = UIColor.dynamicColor(
            lightModeColor: UIColor(hex: CometChatBuilderSettings.shared.style.color.secondaryTextLight),
            darkModeColor: UIColor(hex: CometChatBuilderSettings.shared.style.color.secondaryTextDark)
        )
        
        let font = CometChatBuilderSettings.shared.style.typography.font
        CometChatTypography.setFont(name: fontName(name: font) ?? "")
    }
    
    public static func fontName(name: String) -> String? {
        switch name.lowercased() {
        case "times new roman": return "TimesNewRomanPSMT"
        case "arial": return "ArialMT"
        case "roboto": return "Roboto-Regular"
        case "inter": return "Inter-Regular"
        default: return "\(name.capitalized)-Regular"
        }
    }
    
    public static func setRootViewController(_ viewController: UIViewController) {
        guard let scene = (currentScene as? UIWindowScene) else { return }
        UIView.animate(withDuration: 0.2) {
            window = UIWindow(frame: scene.coordinateSpace.bounds)
            window?.tintColor = CometChatTheme.primaryColor
            window?.windowScene = scene
            let transition = CATransition()
            transition.type = .fade
            transition.duration = 0.3
            window?.layer.add(transition, forKey: kCATransition)
            window?.rootViewController = viewController
            window?.makeKeyAndVisible()
        }
    }
    
    public static func initialiseCometChatUIKit(completion: @escaping () -> Void) {
        AppConstants.retrieveAppConstants()
        
        if AppConstants.APP_ID.isEmpty || AppConstants.AUTH_KEY.isEmpty || AppConstants.REGION.isEmpty {
            print("Incorrect App Constants")
            completion()
        } else {
            let uikitSettings = UIKitSettings()
            uikitSettings.set(appID: AppConstants.APP_ID)
                .set(authKey: AppConstants.AUTH_KEY)
                .set(region: AppConstants.REGION)
                .setExtensionGroupID(id: "group.com.cometchat.internal.swift.notification")
                .subscribePresenceForAllUsers()
                .build()
            
            CometChatUIKit.init(uiKitSettings: uikitSettings, result: { result in
                switch result {
                case .success(_):
                    CometChat.setSource(resource: "uikit-v5", platform: "ios", language: "swift")
                    completion()
                case .failure(let error):
                    print("Initialization Error: \(error.localizedDescription)")
                    completion()
                }
            })
        }
    }
}
