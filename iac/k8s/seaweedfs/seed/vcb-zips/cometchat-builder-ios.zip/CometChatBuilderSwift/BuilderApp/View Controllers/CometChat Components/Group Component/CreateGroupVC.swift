//
//  CometChatCreateGroup.swift
//  Sample App
//
//  Created by Dawinder on 16/10/24.
//

import Foundation
import UIKit
import CometChatSDK
import CometChatUIKitSwift

public class CreateGroupVC: UIViewController {

    // MARK: - UI Components
    public let groupImageBackView = UIImageView()
    public let groupImage = UIImageView()
    public let titleLabel = UILabel()
    public let closeButton = UIButton(type: .system)
    public let typeLabel = UILabel()
    public let segmentedControl = UISegmentedControl(items: ["PUBLIC".localize(), "PRIVATE".localize(), "PASSWORD".localize()])
    public let nameLabel = UILabel()
    public let nameTextFieldView = UIView()
    public let nameTextField = UITextField()
    public let passwordLabel = UILabel()
    public let passwordTextFieldView = UIView()
    public let passwordTextField = UITextField()
    public let fieldsStackView = UIStackView()
    public let createGroupButton = UIButton(type: .system)
    public var loadingIndicator: UIActivityIndicatorView?
    public let scrollView = UIScrollView()
    public let contentView = UIView()
    public var scrollViewBottomAnchor: NSLayoutConstraint?
    
    // MARK: - Callbacks
    var success: ((CometChatSDK.Group) -> Void)?
    var failure: ((CometChatSDK.CometChatException) -> Void)?
    var openGroupChat: ((Group) -> ())?
    
    // MARK: - Lifecycle
    public override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        configureSegmentedControl()
        createGroupButton.addTarget(self, action: #selector(createGroupButtonTapped), for: .touchUpInside)
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(dismissKeyboard))
        self.view.addGestureRecognizer(tapGesture)
        
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow(_:)), name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide(_:)), name: UIResponder.keyboardWillHideNotification, object: nil)

    }
    
    @objc public func dismissKeyboard() {
        view.endEditing(true)
    }
    
    @objc public func keyboardWillShow(_ notification: Notification) {
        if let keyboardFrame = notification.userInfo?[UIResponder.keyboardFrameEndUserInfoKey] as? CGRect {
            let keyboardHeight = keyboardFrame.height
            scrollViewBottomAnchor?.constant = -keyboardHeight
            UIView.animate(withDuration: 0.2) { [weak self] in
                self?.view?.layoutIfNeeded()
            }
        }
    }

    @objc public func keyboardWillHide(_ notification: Notification) {
        scrollViewBottomAnchor?.constant = 0
    }

    // MARK: - UI Setup
    public func setupUI() {
        setupView()
        setupGroupImageBackView()
        setupGroupImage()
        setupTitleLabel()
        setupCloseButton()
        setupTypeLabel()
        setupSegmentedControl()
        setupNameFields()
        setupPasswordFields()
        setupFieldsStackView()
        setupCreateGroupButton()
        setupScrollView()
        setupConstraints()
    }

    public func setupView() {
        self.view.layer.cornerRadius = 16
        self.view.translatesAutoresizingMaskIntoConstraints = false
        self.view.backgroundColor = CometChatTheme.backgroundColor01
    }
    
    public func setupGroupImageBackView(){
        groupImageBackView.backgroundColor = CometChatTheme.backgroundColor02
        groupImageBackView.layer.cornerRadius = 40
        groupImageBackView.translatesAutoresizingMaskIntoConstraints = false
        contentView.addSubview(groupImageBackView)
    }
    
    public func setupGroupImage(){
        groupImage.image = UIImage(named: "new-group-icon", in: CometChatUIKit.bundle, with: nil)?.withRenderingMode(.alwaysTemplate)
        groupImage.tintColor = CometChatTheme.primaryColor
        groupImage.translatesAutoresizingMaskIntoConstraints = false
        contentView.addSubview(groupImage)
    }

    public func setupTitleLabel() {
        titleLabel.text = "NEW_GROUP".localize()
        titleLabel.textAlignment = .center
        titleLabel.textColor = CometChatTheme.textColorPrimary
        titleLabel.font = CometChatTypography.Heading2.medium
        titleLabel.translatesAutoresizingMaskIntoConstraints = false
        contentView.addSubview(titleLabel)
    }

    public func setupCloseButton() {
        closeButton.setImage(UIImage(systemName: "xmark")?.withRenderingMode(.alwaysTemplate), for: .normal)
        closeButton.tintColor = .black
        closeButton.translatesAutoresizingMaskIntoConstraints = false
        closeButton.addTarget(self, action: #selector(closeTapped), for: .touchUpInside)
    }

    public func setupTypeLabel() {
        typeLabel.text = "TYPE".localize()
        typeLabel.font = CometChatTypography.Caption1.medium
        typeLabel.textColor = CometChatTheme.textColorPrimary
        typeLabel.translatesAutoresizingMaskIntoConstraints = false
        contentView.addSubview(typeLabel)
    }

    public func setupSegmentedControl() {
        segmentedControl.backgroundColor = CometChatTheme.backgroundColor01
        segmentedControl.selectedSegmentTintColor = CometChatTheme.backgroundColor01
        segmentedControl.selectedSegmentIndex = 0
        segmentedControl.isOpaque = true
        
        let normalTextAttributes: [NSAttributedString.Key: Any] = [
            .foregroundColor: CometChatTheme.textColorSecondary,
            .font: CometChatTypography.Body.regular
        ]
        segmentedControl.setTitleTextAttributes(normalTextAttributes, for: .normal)
        
        let selectedTextAttributes: [NSAttributedString.Key: Any] = [
            .foregroundColor: CometChatTheme.textColorHighlight,
            .font: CometChatTypography.Body.medium
        ]
        segmentedControl.setTitleTextAttributes(selectedTextAttributes, for: .selected)
        
        segmentedControl.addTarget(self, action: #selector(segmentedControlValueChanged), for: .valueChanged)
        segmentedControl.translatesAutoresizingMaskIntoConstraints = false
        contentView.addSubview(segmentedControl)
    }

    public func setupNameFields() {
        nameLabel.text = "NAME".localize()
        nameLabel.font = CometChatTypography.Caption1.medium
        nameLabel.textColor = CometChatTheme.textColorPrimary
        nameLabel.translatesAutoresizingMaskIntoConstraints = false

        nameTextField.placeholder = "ENTER_GROUP_NAME".localize()
        nameTextField.attributedPlaceholder = NSAttributedString(
            string: "ENTER_GROUP_NAME".localize(),
            attributes: [NSAttributedString.Key.foregroundColor: CometChatTheme.textColorTertiary, .font: CometChatTypography.Body.regular]
        )
        nameTextField.borderStyle = .none
        nameTextField.backgroundColor = .clear
        nameTextFieldView.backgroundColor = CometChatTheme.backgroundColor02
        nameTextFieldView.layer.borderWidth = 1
        nameTextFieldView.layer.borderColor = CometChatTheme.borderColorLight.cgColor
        nameTextFieldView.layer.cornerRadius = 8
        nameTextField.translatesAutoresizingMaskIntoConstraints = false
        nameTextFieldView.translatesAutoresizingMaskIntoConstraints = false
        nameTextFieldView.addSubview(nameTextField)
    }

    public func setupPasswordFields() {
        passwordLabel.text = "PASSWORD".localize()
        passwordLabel.font = CometChatTypography.Caption1.medium
        passwordLabel.textColor = CometChatTheme.textColorPrimary
        passwordLabel.translatesAutoresizingMaskIntoConstraints = false

        passwordTextField.placeholder = "ENTER_PASSWORD".localize()
        passwordTextField.attributedPlaceholder = NSAttributedString(
            string: "ENTER_PASSWORD".localize(),
            attributes: [NSAttributedString.Key.foregroundColor: CometChatTheme.textColorTertiary, .font: CometChatTypography.Body.regular]
        )
        passwordTextField.borderStyle = .none
        passwordTextField.backgroundColor = .clear
        passwordTextFieldView.backgroundColor = CometChatTheme.backgroundColor02
        passwordTextFieldView.layer.borderWidth = 1
        passwordTextFieldView.layer.borderColor = CometChatTheme.borderColorLight.cgColor
        passwordTextFieldView.layer.cornerRadius = 8
        passwordTextField.translatesAutoresizingMaskIntoConstraints = false
        passwordTextFieldView.translatesAutoresizingMaskIntoConstraints = false
        passwordTextFieldView.addSubview(passwordTextField)

        passwordLabel.isHidden = true
        passwordTextFieldView.isHidden = true
    }

    public func setupFieldsStackView() {
        fieldsStackView.axis = .vertical
        fieldsStackView.distribution = .fill
        fieldsStackView.alignment = .fill
        fieldsStackView.spacing = 20
        fieldsStackView.translatesAutoresizingMaskIntoConstraints = false
        fieldsStackView.addArrangedSubview(nameLabel)
        fieldsStackView.setCustomSpacing(4, after: nameLabel)
        fieldsStackView.addArrangedSubview(nameTextFieldView)
        fieldsStackView.addArrangedSubview(passwordLabel)
        fieldsStackView.setCustomSpacing(4, after: passwordLabel)
        fieldsStackView.addArrangedSubview(passwordTextFieldView)
        contentView.addSubview(fieldsStackView)
    }

    public func setupCreateGroupButton() {
        createGroupButton.setTitle("CREATE_GROUP".localize(), for: .normal)
        createGroupButton.backgroundColor = CometChatTheme.primaryColor
        createGroupButton.setTitleColor(CometChatTheme.buttonTextColor, for: .normal)
        createGroupButton.titleLabel?.font = CometChatTypography.Button.medium
        createGroupButton.layer.cornerRadius = 8
        createGroupButton.translatesAutoresizingMaskIntoConstraints = false
        contentView.addSubview(createGroupButton)
    }

    // MARK: - Constraints Setup
    public func setupScrollView() {
        // Add the scroll view and content view
        scrollView.translatesAutoresizingMaskIntoConstraints = false
        contentView.translatesAutoresizingMaskIntoConstraints = false
        self.view.addSubview(scrollView)
        scrollView.addSubview(contentView)
        
        // Set scroll view constraints
        scrollViewBottomAnchor = scrollView.bottomAnchor.constraint(equalTo: self.view.bottomAnchor)
        NSLayoutConstraint.activate([
            scrollView.topAnchor.constraint(equalTo: self.view.topAnchor),
            scrollView.leadingAnchor.constraint(equalTo: self.view.leadingAnchor),
            scrollView.trailingAnchor.constraint(equalTo: self.view.trailingAnchor),
            scrollViewBottomAnchor!,
        ])
        
        // Set content view constraints
        NSLayoutConstraint.activate([
            contentView.topAnchor.constraint(equalTo: scrollView.topAnchor),
            contentView.leadingAnchor.constraint(equalTo: scrollView.leadingAnchor),
            contentView.trailingAnchor.constraint(equalTo: scrollView.trailingAnchor),
            contentView.bottomAnchor.constraint(equalTo: scrollView.bottomAnchor),
            contentView.widthAnchor.constraint(equalTo: scrollView.widthAnchor), // Important for vertical scrolling
        ])
    }

    public func setupConstraints() {
        NSLayoutConstraint.activate([
            // Group Image Constraints
            groupImageBackView.centerXAnchor.constraint(equalTo: contentView.centerXAnchor),
            groupImageBackView.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 32),
            groupImageBackView.heightAnchor.constraint(equalToConstant: 80),
            groupImageBackView.widthAnchor.constraint(equalToConstant: 80),
            groupImage.centerXAnchor.constraint(equalTo: groupImageBackView.centerXAnchor),
            groupImage.centerYAnchor.constraint(equalTo: groupImageBackView.centerYAnchor),
            groupImage.heightAnchor.constraint(equalToConstant: 48),
            groupImage.widthAnchor.constraint(equalToConstant: 48),
            
            // Title Label Constraints
            titleLabel.topAnchor.constraint(equalTo: groupImageBackView.bottomAnchor, constant: 8),
            titleLabel.centerXAnchor.constraint(equalTo: contentView.centerXAnchor),
            titleLabel.heightAnchor.constraint(equalToConstant: 24),
            nameLabel.heightAnchor.constraint(equalToConstant: 14),
            passwordLabel.heightAnchor.constraint(equalToConstant: 14),
            typeLabel.heightAnchor.constraint(equalToConstant: 14),

            // Type Label Constraints
            typeLabel.topAnchor.constraint(equalTo: titleLabel.bottomAnchor, constant: 20),
            typeLabel.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 20),

            // Segmented Control Constraints
            segmentedControl.topAnchor.constraint(equalTo: typeLabel.bottomAnchor, constant: 4),
            segmentedControl.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 20),
            segmentedControl.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -20),
            segmentedControl.heightAnchor.constraint(equalToConstant: 28),
            
            nameTextField.leadingAnchor.constraint(equalTo: nameTextFieldView.leadingAnchor, constant: 8),
            nameTextField.trailingAnchor.constraint(equalTo: nameTextFieldView.trailingAnchor, constant: -8),
            nameTextField.topAnchor.constraint(equalTo: nameTextFieldView.topAnchor),
            nameTextField.bottomAnchor.constraint(equalTo: nameTextFieldView.bottomAnchor),
            nameTextFieldView.heightAnchor.constraint(equalToConstant: 36),
            nameTextField.heightAnchor.constraint(equalToConstant: 36),
            
            passwordTextField.leadingAnchor.constraint(equalTo: passwordTextFieldView.leadingAnchor, constant: 8),
            passwordTextField.trailingAnchor.constraint(equalTo: passwordTextFieldView.trailingAnchor, constant: -8),
            passwordTextField.topAnchor.constraint(equalTo: passwordTextFieldView.topAnchor),
            passwordTextField.bottomAnchor.constraint(equalTo: passwordTextFieldView.bottomAnchor),
            passwordTextFieldView.heightAnchor.constraint(equalToConstant: 36),

            // Fields Stack View Constraints
            fieldsStackView.topAnchor.constraint(equalTo: segmentedControl.bottomAnchor, constant: 20),
            fieldsStackView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 20),
            fieldsStackView.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -20),

            // Create Group Button Constraints
            createGroupButton.topAnchor.constraint(equalTo: fieldsStackView.bottomAnchor, constant: 30),
            createGroupButton.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 20),
            createGroupButton.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -20),
            createGroupButton.heightAnchor.constraint(equalToConstant: 40),
            createGroupButton.bottomAnchor.constraint(equalTo: contentView.bottomAnchor, constant: -20), // Important for scrollable content
        ])
    }
}

extension CreateGroupVC{
    // MARK: - Actions
    @objc public func closeTapped() {
        dismiss(animated: true, completion: nil)
    }

    @objc public func segmentedControlValueChanged() {
        let isPasswordGroup = segmentedControl.selectedSegmentIndex == 2
        
        UIView.animate(withDuration: 0.3, animations: {
            if isPasswordGroup {
                // Slide the password fields into view
                self.passwordLabel.isHidden = false
                self.passwordTextFieldView.isHidden = false
                
                self.passwordLabel.alpha = 1
                self.passwordTextFieldView.alpha = 1
                
                if #available(iOS 15.0, *) {
                    let newHeight = 440
                    self.manageSheetHeight(height: newHeight)
                } else {
                    // Fallback on earlier versions
                }
                // Adjust any layout if necessary (optional)
                self.fieldsStackView.layoutIfNeeded()
            } else {
                // Slide the password fields out of view
                if #available(iOS 15.0, *) {
                    let newHeight = 356
                    self.manageSheetHeight(height: newHeight)
                } else {
                    // Fallback on earlier versions
                }
                self.passwordLabel.alpha = 0
                self.passwordTextFieldView.alpha = 0
                self.passwordLabel.isHidden = true
                self.passwordTextFieldView.isHidden = true
            }
        }, completion: { _ in
            if !isPasswordGroup {
                // After the animation is done, fully hide the fields (no visible space)
                self.passwordLabel.isHidden = true
                self.passwordTextFieldView.isHidden = true
            }
        })
    }

    @objc public func createGroupButtonTapped() {
        guard let groupName = nameTextField.text, !groupName.isEmpty else {
            showError(message: "EMPTY_GROUP_NAME_ERROR".localize())
            return
        }

        if segmentedControl.selectedSegmentIndex == 2,
           let password = passwordTextField.text, password.isEmpty {
            showError(message: "EMPTY_PASSWORD_ERROR".localize())
            return
        }

        createGroup()
    }
    
    public func configureSegmentedControl() {
        segmentedControl.addTarget(self, action: #selector(segmentedControlValueChanged), for: .valueChanged)
    }
}

extension CreateGroupVC{
    // MARK: - Helper Methods
    public func createGroup() {
        showLoader()
        
        guard let groupName = nameTextField.text else { return }
        var password: String?
        var groupType: CometChat.groupType = .public
        
        if segmentedControl.selectedSegmentIndex == 0{
            groupType = .public
        }else if segmentedControl.selectedSegmentIndex == 1{
            groupType = .private
        }else{
            groupType = .password
            password = self.passwordTextField.text ?? ""
        }
        
        let group = Group(guid: "group_\(Int(Date().timeIntervalSince1970 * 100))", name: groupName, groupType: groupType, password: password)
        
        CometChat.createGroup(group: group) { [weak self] group in
            DispatchQueue.main.async {
                self?.handleGroupCreationSuccess(group)
                CometChatUIKitHelper.onGroupCreated(group: group)
            }
        } onError: { [weak self] error in
            self?.handleGroupCreationError(error)
        }
    }

    public func handleGroupCreationSuccess(_ group: Group) {
        success?(group)
        dismiss(animated: true) {
            self.openGroupChat?(group)
        }
        hideLoader()
    }

    public func handleGroupCreationError(_ error: CometChatException?) {
        if let error = error {
            failure?(error)
        }
        hideLoader()
    }

    public func showError(message: String) {
        let alert = UIAlertController(title: "", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK".localize(), style: .default))
        present(alert, animated: true)
    }

    public func showLoader() {
        if loadingIndicator == nil {
            loadingIndicator = UIActivityIndicatorView(style: .medium)
            loadingIndicator?.translatesAutoresizingMaskIntoConstraints = false
            createGroupButton.addSubview(loadingIndicator!)
            
            NSLayoutConstraint.activate([
                loadingIndicator!.centerXAnchor.constraint(equalTo: createGroupButton.centerXAnchor),
                loadingIndicator!.centerYAnchor.constraint(equalTo: createGroupButton.centerYAnchor)
            ])
        }

        createGroupButton.setTitle("", for: .normal)
        loadingIndicator?.startAnimating()
    }

    public func hideLoader() {
        DispatchQueue.main.async {
            self.loadingIndicator?.stopAnimating()
            self.createGroupButton.setTitle("CREATE_GROUP".localize(), for: .normal)
        }
    }
    
    public func manageSheetHeight(height: Int){
        if #available(iOS 15.0, *) {
            if let sheetController = self.sheetPresentationController {
                if #available(iOS 16.0, *) {
                    let customDetent = UISheetPresentationController.Detent.custom { _ in
                        return CGFloat(height)
                    }
                    sheetController.detents = [customDetent]
                }
            }
        } else {
            // Fallback on earlier versions
        }
    }
}
