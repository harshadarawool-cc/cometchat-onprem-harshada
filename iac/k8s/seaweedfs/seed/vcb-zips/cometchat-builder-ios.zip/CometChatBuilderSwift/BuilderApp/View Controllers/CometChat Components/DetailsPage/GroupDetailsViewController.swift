//
//  GroupInfoViewController.swift
//  Sample App
//
//  Created by Dawinder on 20/10/24.
//

import Foundation
import UIKit
import CometChatSDK
import CometChatUIKitSwift
import CometChatBuilder

public class GroupDetailsViewController: UIViewController {

    // MARK: - UI Components
    public let scrollView = UIScrollView()
    public let contentView = UIView()
    public var group : Group?
    
    public let topStackView: UIStackView = {
        let view = UIStackView()
        view.translatesAutoresizingMaskIntoConstraints = false
        view.axis = .vertical
        view.alignment = .center
        view.distribution = .fill
        view.spacing = 20
        return view
    }()
    
    public lazy var buttonSectionStackView: UIStackView = {
        let stackView = UIStackView()
        stackView.axis = .vertical
        stackView.distribution = .fillProportionally
        stackView.alignment = .center
        stackView.spacing = 20
        stackView.translatesAutoresizingMaskIntoConstraints = false
        return stackView
    }()
    
    public let groupErrorView: UIView = {
        let view = UIView()
        view.translatesAutoresizingMaskIntoConstraints = false
        view.backgroundColor = CometChatTheme.warningColor
        view.heightAnchor.constraint(equalToConstant: 30).isActive = true
        return view
    }()
    
    public let iconImageView: UIImageView = {
        let imageView = UIImageView()
        imageView.image = UIImage(systemName: "info.circle")
        imageView.tintColor = CometChatTheme.iconColorPrimary
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.heightAnchor.constraint(equalToConstant: 24).isActive = true
        imageView.widthAnchor.constraint(equalToConstant: 24).isActive = true
        return imageView
    }()
    
    public let messageLabel: UILabel = {
        let label = UILabel()
        label.text = "NO_LONGER_IN_GROUP_ERROR".localize()
        label.font = CometChatTypography.Heading4.regular
        label.textColor = CometChatTheme.textColorPrimary
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    public let errorstackView: UIStackView = {
        let stackView = UIStackView()
        stackView.axis = .horizontal
        stackView.alignment = .center
        stackView.spacing = 8
        stackView.translatesAutoresizingMaskIntoConstraints = false
        return stackView
    }()
    
    public let groupImageView: CometChatAvatar = {
        let imageView = CometChatAvatar(frame: .zero)
        imageView.layer.cornerRadius = 60
        imageView.clipsToBounds = true
        imageView.style.textFont = CometChatTypography.Title.bold
        return imageView
    }()
    
    public let groupNameLabel: UILabel = {
        let label = UILabel()
        label.font = CometChatTypography.Heading2.medium
        label.textColor = CometChatTheme.textColorPrimary
        label.textAlignment = .center
        return label
    }()
    
    public let memberCountLabel: UILabel = {
        let label = UILabel()
        label.font = CometChatTypography.Caption1.regular
        label.textColor = CometChatTheme.textColorSecondary
        label.textAlignment = .center
        return label
    }()
    
    public let sepearatorView : UIView = {
        let view = UIView()
        view.backgroundColor = CometChatTheme.borderColorLight
        return view
    }()
    
    public let addMembersView = GroupActionView(title: "ADD_MEMBERS".localize(), image: UIImage(systemName: "person.badge.plus"))
    public let viewMembersView = GroupActionView(title: "VIEW_MEMBERS".localize(), image: UIImage(systemName: "person.2"))
    public let bannedMembersView = GroupActionView(title: "BANNED_MEMBERS".localize(), image: UIImage(named: "ban_member")?.withRenderingMode(.alwaysTemplate))
    
    public var listenerRandomID = Date().timeIntervalSince1970
    public var onExitGroup: ((_ group: Group) -> ())?
    
    public let bottomContainerStackView: UIStackView = {
        let stackView = UIStackView()
        stackView.translatesAutoresizingMaskIntoConstraints = false
        stackView.axis = .vertical
        stackView.spacing = CometChatSpacing.Padding.p6
        stackView.distribution = .fillEqually
        stackView.alignment = .leading
        stackView.isUserInteractionEnabled = true
        return stackView
    }()
    
    public lazy var leaveButton: UIButton = {
        let button = UIButton(type: .system)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.heightAnchor.constraint(equalToConstant: 35).isActive = true
        button.setTitle("LEAVE".localize(), for: .normal)
        button.setTitleColor(CometChatTheme.errorColor, for: .normal)
        button.setImage(UIImage(systemName: "rectangle.portrait.and.arrow.right"), for: .normal)
        button.tintColor = CometChatTheme.errorColor
        
        // Set spacing between the image and title
        let spacing: CGFloat = 8.0
        button.imageView?.contentMode = .scaleAspectFit
        
        button.titleEdgeInsets = UIEdgeInsets(top: 0, left: spacing, bottom: 0, right: -spacing)
        button.imageEdgeInsets = UIEdgeInsets(top: 0, left: -spacing, bottom: 0, right: 0)
        
        // Ensure content is centered
        button.contentHorizontalAlignment = .center
        button.contentVerticalAlignment = .center
        button.titleLabel?.font = CometChatTypography.Heading4.regular
        button.addTarget(self, action: #selector(showLeaveGroupAlert), for: .primaryActionTriggered)
        return button
    }()
    
    public lazy var deleteChatButton: UIButton = {
        let button = UIButton(type: .system)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.heightAnchor.constraint(equalToConstant: 35).isActive = true
        button.setTitle("DELETE_CHAT".localize(), for: .normal)
        button.setTitleColor(CometChatTheme.errorColor, for: .normal)
        button.setImage(UIImage(systemName: "trash"), for: .normal)
        button.tintColor = CometChatTheme.errorColor
        
        // Set spacing between the image and title
        let spacing: CGFloat = 8.0
        button.imageView?.contentMode = .scaleAspectFit
        
        button.titleEdgeInsets = UIEdgeInsets(top: 0, left: spacing, bottom: 0, right: -spacing)
        button.imageEdgeInsets = UIEdgeInsets(top: 0, left: -spacing, bottom: 0, right: 0)
        
        // Ensure content is centered
        button.contentHorizontalAlignment = .center
        button.contentVerticalAlignment = .center
        button.titleLabel?.font = CometChatTypography.Heading4.regular
        button.addTarget(self, action: #selector(showDeleteChatAlert), for: .primaryActionTriggered)
        return button
    }()
    
    public lazy var deleteAndExitButton: UIButton = {
        let button = UIButton(type: .system)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.heightAnchor.constraint(equalToConstant: 35).isActive = true
        button.setTitle("DELETE_AND_EXIT".localize(), for: .normal)
        button.setTitleColor(CometChatTheme.errorColor, for: .normal)
        button.setImage(UIImage(systemName: "trash"), for: .normal)
        button.tintColor = CometChatTheme.errorColor
        
        // Set spacing between the image and title
        let spacing: CGFloat = 8.0
        button.imageView?.contentMode = .scaleAspectFit
        
        button.titleEdgeInsets = UIEdgeInsets(top: 0, left: spacing, bottom: 0, right: -spacing)
        button.imageEdgeInsets = UIEdgeInsets(top: 0, left: -spacing, bottom: 0, right: 0)
        
        // Ensure content is centered
        button.contentHorizontalAlignment = .center
        button.contentVerticalAlignment = .center
        button.titleLabel?.font = CometChatTypography.Heading4.regular
        button.addTarget(self, action: #selector(showDeleteGroupAlert), for: .primaryActionTriggered)
        
        return button
    }()
    
    var buttonStackView: UIStackView!

    
    // MARK: - Lifecycle Methods
    override public func viewDidLoad() {
        super.viewDidLoad()
        connect()
        view.backgroundColor = CometChatTheme.backgroundColor01
        setupScrollView()
        setupLayout()
        addButtonActions()
        if !CometChatBuilderSettings.shared.chatFeatures.groupManagement.addMembersToGroups{
            addMembersView.isHidden = true
        }
        if !CometChatBuilderSettings.shared.chatFeatures.groupManagement.viewGroupMembers{
            viewMembersView.isHidden = true
            bannedMembersView.isHidden = true
        }
        if !CometChatBuilderSettings.shared.chatFeatures.groupManagement.deleteGroup{
            deleteAndExitButton.isHidden = true
        }
        if !CometChatBuilderSettings.shared.chatFeatures.groupManagement.joinLeaveGroup{
            leaveButton.isHidden = true
        }
    }
    
    override public func viewWillAppear(_ animated: Bool) {
        setupNavigationBar()
    }
    
    deinit {
        disconnect()
    }
    
    // MARK: - Setup Navigation Bar
    public func setupNavigationBar() {
        navigationItem.title = "GROUP_INFO".localize()
        navigationController?.navigationBar.prefersLargeTitles = true
        navigationController?.navigationBar.tintColor = CometChatTheme.iconColorPrimary
    }

    // MARK: - Setup ScrollView and ContentView
    public func setupScrollView() {
        view.addSubview(scrollView)
        scrollView.translatesAutoresizingMaskIntoConstraints = false
        scrollView.topAnchor.constraint(equalTo: view.topAnchor).isActive = true
        scrollView.bottomAnchor.constraint(equalTo: view.bottomAnchor).isActive = true
        scrollView.leadingAnchor.constraint(equalTo: view.leadingAnchor).isActive = true
        scrollView.trailingAnchor.constraint(equalTo: view.trailingAnchor).isActive = true
        
        scrollView.addSubview(contentView)
        contentView.translatesAutoresizingMaskIntoConstraints = false
        contentView.topAnchor.constraint(equalTo: scrollView.topAnchor).isActive = true
        contentView.bottomAnchor.constraint(equalTo: scrollView.bottomAnchor).isActive = true
        contentView.leadingAnchor.constraint(equalTo: scrollView.leadingAnchor).isActive = true
        contentView.trailingAnchor.constraint(equalTo: scrollView.trailingAnchor).isActive = true
        contentView.widthAnchor.constraint(equalTo: scrollView.widthAnchor).isActive = true
    }
    
    // MARK: - Setup Layout
    public func setupLayout() {
        [topStackView, groupImageView, groupNameLabel, memberCountLabel, buttonSectionStackView, bottomContainerStackView].forEach { contentView.addSubview($0) }
        
        topStackView.addArrangedSubview(groupErrorView)
        topStackView.addArrangedSubview(groupImageView)
        groupErrorView.addSubview(errorstackView)
        errorstackView.addArrangedSubview(iconImageView)
        errorstackView.addArrangedSubview(messageLabel)
        
        errorstackView.leadingAnchor.constraint(equalTo: groupErrorView.leadingAnchor, constant: 16).isActive = true
        errorstackView.trailingAnchor.constraint(equalTo: groupErrorView.trailingAnchor, constant: -16).isActive = true
        errorstackView.topAnchor.constraint(equalTo: groupErrorView.topAnchor).isActive = true
        errorstackView.bottomAnchor.constraint(equalTo: groupErrorView.bottomAnchor).isActive = true
        
        groupImageView.translatesAutoresizingMaskIntoConstraints = false
        topStackView.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 20).isActive = true
        topStackView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor).isActive = true
        topStackView.trailingAnchor.constraint(equalTo: contentView.trailingAnchor).isActive = true
        
        groupErrorView.leadingAnchor.constraint(equalTo: topStackView.leadingAnchor).isActive = true
        groupErrorView.trailingAnchor.constraint(equalTo: topStackView.trailingAnchor).isActive = true
        groupImageView.widthAnchor.constraint(equalToConstant: 120).isActive = true
        groupImageView.heightAnchor.constraint(equalToConstant: 120).isActive = true
        
        groupNameLabel.translatesAutoresizingMaskIntoConstraints = false
        groupNameLabel.topAnchor.constraint(equalTo: groupImageView.bottomAnchor, constant: 20).isActive = true
        groupNameLabel.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 16).isActive = true
        groupNameLabel.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -16).isActive = true
        
        memberCountLabel.translatesAutoresizingMaskIntoConstraints = false
        memberCountLabel.topAnchor.constraint(equalTo: groupNameLabel.bottomAnchor, constant: 8).isActive = true
        memberCountLabel.centerXAnchor.constraint(equalTo: contentView.centerXAnchor).isActive = true
        
        // Create button stack view
        buttonStackView = UIStackView(arrangedSubviews: [viewMembersView, addMembersView, bannedMembersView])
        buttonStackView.axis = .horizontal
        buttonStackView.distribution = .fillEqually
        buttonStackView.spacing = 8
        buttonStackView.translatesAutoresizingMaskIntoConstraints = false
        buttonStackView.heightAnchor.constraint(equalToConstant: 70).isActive = true
        
        // Add buttonStackView + sepearatorView into buttonSectionStackView
        buttonSectionStackView.addArrangedSubview(buttonStackView)
        buttonSectionStackView.addArrangedSubview(sepearatorView)
        
        // Constraints for buttonSectionStackView
        buttonSectionStackView.topAnchor.constraint(equalTo: memberCountLabel.bottomAnchor, constant: 20).isActive = true
        buttonSectionStackView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor).isActive = true
        buttonSectionStackView.trailingAnchor.constraint(equalTo: contentView.trailingAnchor).isActive = true
        
        buttonStackView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 16).isActive = true
        buttonStackView.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -16).isActive = true
        
        sepearatorView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor).isActive = true
        sepearatorView.trailingAnchor.constraint(equalTo: contentView.trailingAnchor).isActive = true
        
        sepearatorView.translatesAutoresizingMaskIntoConstraints = false
        sepearatorView.heightAnchor.constraint(equalToConstant: 1).isActive = true
        
        bottomContainerStackView.topAnchor.constraint(equalTo: buttonSectionStackView.bottomAnchor, constant: 20).isActive = true
        bottomContainerStackView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 30).isActive = true
        bottomContainerStackView.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -20).isActive = true
        bottomContainerStackView.bottomAnchor.constraint(equalTo: contentView.bottomAnchor, constant: -20).isActive = true
        bottomContainerStackView.addArrangedSubview(leaveButton)
        bottomContainerStackView.addArrangedSubview(deleteChatButton)
        bottomContainerStackView.addArrangedSubview(deleteAndExitButton)
        
        groupNameLabel.text = group?.name
        groupImageView.setAvatar(avatarUrl: group?.icon ?? "", with: group?.name ?? "")
        
        if let group = group {
            updateGroupInfo(group)
        }
        
        if let _ = group?.hasJoined {
            groupErrorView.isHidden = true
        } else {
            groupErrorView.isHidden = false
        }
        
        if !CometChatBuilderSettings.shared.chatFeatures.groupManagement.addMembersToGroups && !CometChatBuilderSettings.shared.chatFeatures.groupManagement.viewGroupMembers{
            buttonStackView.isHidden = true
        }
    }
    
    @objc public func showDeleteGroupAlert(){
        self.showAlert("DELETE_AND_EXIT_QUESTION_MARK".localize(), "CONFIRM_DELETE_AND_EXIT_GROUP_ALERT".localize(), "CANCEL".localize(), "DELETE_AND_EXIT".localize(), onActionsTriggered: {
            if let group = self.group {
                CometChat.deleteGroup(GUID: group.guid) { deleteSuccess in
                    DispatchQueue.main.async { [weak self] in
                        CometChatGroupEvents.ccGroupDeleted(group: group)
                        self?.navigationController?.popToViewController(ofClass: HomeScreenViewController.self)
                        self?.onExitGroup?(group)
                    }
                } onError: { error in
                    print("Something want wrong")
                }
            }
        })
    }
    
    @objc func showDeleteChatAlert(){
        self.showAlert("DELETE_CHAT".localize(), "DELETE_CHAT_CONFIRMATION".localize(), "CANCEL".localize(), "DELETE".localize(), onActionsTriggered: { [weak self] in
            if let group = self?.group {
                self?.getConversation { deletedConversation in
                    CometChat.deleteConversation(conversationWith: group.guid, conversationType: .group) { [weak self] message in
                        DispatchQueue.main.async {
                            CometChatConversationEvents.ccConversationDeleted(conversation: deletedConversation)
                            self?.navigationController?.popToViewController(ofClass: HomeScreenViewController.self, animated: true)
                        }
                    } onError: { error in
                        //TODO: ERROR
                    }
                }
            }
        })
    }
    
    @objc func showLeaveGroupAlert(){
        if group?.owner == CometChat.getLoggedInUser()?.uid && (group?.membersCount ?? 0) > 1 {
            self.showAlert("OWNERSHIP_TRANSFER".localize(), "TRANSFER_OWNERSHIP_ALERT".localize(), "CANCEL".localize(), "TRANSFER".localize(), onActionsTriggered: {
                if let group = self.group {
                    let transferOwnership = TransferOwnership()
                    transferOwnership.set(group: group)
                    transferOwnership.leaveGroupCallback = {
                        self.leaveGroup(group: group)
                    }
                    self.present(UINavigationController(rootViewController: transferOwnership), animated: true)
                }
            })
        } else {
            self.showAlert("LEAVE_GROUP_QUESTION_MARK".localize(), "LEAVE_GROUP_ALERT".localize(), "CANCEL".localize(), "LEAVE".localize(), onActionsTriggered: {
                if let group = self.group {
                    self.leaveGroup(group: group)
                }
            })
        }
    }
    
    public func leaveGroup(group:Group){
        CometChat.leaveGroup(GUID: group.guid) { leaveSuccess in
            DispatchQueue.main.async { [weak self] in
                print("group left")
                self?.navigationController?.popToViewController(ofClass: HomeScreenViewController.self)
                if let user = CometChat.getLoggedInUser(), let group = self?.group {
                    
                    let actionMessage = ActionMessage()
                    actionMessage.action = .scopeChanged
                    actionMessage.conversationId = "group_\(group.guid)"
                    actionMessage.message = "\(user.name ?? "") left"
                    actionMessage.muid = "\(NSDate().timeIntervalSince1970)"
                    actionMessage.sender = user
                    actionMessage.receiver = group
                    actionMessage.actionBy = user
                    actionMessage.actionOn = user
                    actionMessage.receiverUid = group.guid
                    actionMessage.messageType = .groupMember
                    actionMessage.messageCategory = .action
                    actionMessage.receiverType = .group
                    actionMessage.sentAt = Int(Date().timeIntervalSince1970)
                    
                    group.hasJoined = false
                    group.membersCount = group.membersCount - 1
                    CometChatGroupEvents.ccGroupLeft(action: actionMessage, leftUser: user, leftGroup: group)
                }
                self?.onExitGroup?(group)
            }
        } onError: { error in
            print("Something want wrong")
        }
    }
    
    public func showHideOptions(hideViewMembers:Bool, hideAddMembers:Bool, hideBannMembers: Bool, hideLeaveGroup: Bool, hideDeleteGroup: Bool){
        // Apply role-based visibility AND builder settings
        self.viewMembersView.isHidden = hideViewMembers || !CometChatBuilderSettings.shared.chatFeatures.groupManagement.viewGroupMembers
        self.addMembersView.isHidden = hideAddMembers || !CometChatBuilderSettings.shared.chatFeatures.groupManagement.addMembersToGroups
        self.bannedMembersView.isHidden = hideBannMembers || !CometChatBuilderSettings.shared.chatFeatures.groupManagement.viewGroupMembers
        self.leaveButton.isHidden = hideLeaveGroup || !CometChatBuilderSettings.shared.chatFeatures.groupManagement.joinLeaveGroup
        self.deleteAndExitButton.isHidden = hideDeleteGroup || !CometChatBuilderSettings.shared.chatFeatures.groupManagement.deleteGroup
    }
    
    public func connect() {
        CometChat.addGroupListener("group-info-groups-sdk-listner-\(listenerRandomID)", self)
        CometChatGroupEvents.addListener("group-info-groups-event-listner-\(listenerRandomID)", self)
    }
    
    func getConversation(completion: @escaping((Conversation) -> ())){
        CometChat.getConversation(conversationWith: group?.guid ?? "", conversationType: .group, onSuccess: { conversation in
            if let convo = conversation{
                completion(convo)
            }
        }, onError: { error in
            print("error: \(error?.errorDescription ?? "Unknown error")")
        })
    }
    
    public func disconnect() {
        CometChat.removeGroupListener("group-info-groups-sdk-listner-\(listenerRandomID)")
        CometChatGroupEvents.removeListener("group-info-groups-event-listner-\(listenerRandomID)")
    }
}

extension GroupDetailsViewController{
    
    public func addButtonActions(){
        viewMembersView.onActionButtonTapped = {
            self.viewMembers()
        }
        addMembersView.onActionButtonTapped = {
            self.addMembers()
        }
        bannedMembersView.onActionButtonTapped = {
            self.bannMembers()
        }
    }
    
    public func viewMembers(){
        if let group = self.group {
            let groupMembers = CometChatGroupMembers()
            groupMembers.set(group: group)
            
            groupMembers.hideBanMemberOption = !CometChatBuilderSettings.shared.chatFeatures.moderatorControls.banUsers
            groupMembers.hideKickMemberOption = !CometChatBuilderSettings.shared.chatFeatures.moderatorControls.kickUsers
            groupMembers.hideScopeChangeOption = !CometChatBuilderSettings.shared.chatFeatures.moderatorControls.promoteDemoteMembers
            let navController = UINavigationController(rootViewController: groupMembers)
            self.present(navController, animated: true, completion: nil)
        }
    }
    
    public func bannMembers(){
        if let group = self.group {
            let bannedMembers = BannedMembersVC(group: group)
            let navController = UINavigationController(rootViewController: bannedMembers)
            self.present(navController, animated: true, completion: nil)
        }
    }
    
    public func addMembers(){
        if let group = self.group {
            let addMemberController = AddMembersVC(group: group)
            addMemberController.unableToAddMember = { error in
                self.showAlert(with: error)
            }
            let navController = UINavigationController(rootViewController: addMemberController)
            self.present(navController, animated: true, completion: nil)
        }
    }
}

// MARK: - Custom View for Group Action Buttons
public class GroupActionView: UIView {
    // Closure for button action
    public var onActionButtonTapped: (() -> Void)?
    
    public var actionButton = UIButton(type: .system)
    public var imageView = UIImageView()
    public var titleLabel = UILabel()
    
    init(title: String, image: UIImage?) {
        super.init(frame: .zero)
        setup(title: title, image: image)
        configureButtonAction()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    public func setup(title: String, image: UIImage?) {
        // Configure image view
        imageView.image = image
        imageView.tintColor = CometChatTheme.iconColorHighlight
        imageView.contentMode = .scaleAspectFit
        
        // Configure title label
        titleLabel.text = title
        titleLabel.textColor = CometChatTheme.textColorSecondary
        titleLabel.font = CometChatTypography.Caption1.regular
        titleLabel.textAlignment = .center
        titleLabel.numberOfLines = 0
        titleLabel.adjustsFontSizeToFitWidth = true
        
        // Configure action button
        actionButton.setTitle("", for: .normal) // Button is here just for interaction purposes
        
        // Add subviews
        addSubview(imageView)
        addSubview(titleLabel)
        addSubview(actionButton)
        
        // Add border to the view
        layer.borderWidth = 1
        layer.borderColor = CometChatTheme.borderColorDefault.cgColor
        layer.cornerRadius = 8
        
        // Layout constraints
        imageView.translatesAutoresizingMaskIntoConstraints = false
        titleLabel.translatesAutoresizingMaskIntoConstraints = false
        actionButton.translatesAutoresizingMaskIntoConstraints = false
        
        NSLayoutConstraint.activate([
            imageView.topAnchor.constraint(equalTo: topAnchor, constant: 12),
            imageView.centerXAnchor.constraint(equalTo: centerXAnchor),
            imageView.heightAnchor.constraint(equalToConstant: 24),
            imageView.widthAnchor.constraint(equalToConstant: 24),
            
            titleLabel.topAnchor.constraint(equalTo: imageView.bottomAnchor, constant: 8),
            titleLabel.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 12),
            titleLabel.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -12),
            titleLabel.bottomAnchor.constraint(equalTo: bottomAnchor, constant: -12),
            
            actionButton.topAnchor.constraint(equalTo: topAnchor),
            actionButton.leadingAnchor.constraint(equalTo: leadingAnchor),
            actionButton.trailingAnchor.constraint(equalTo: trailingAnchor),
            actionButton.bottomAnchor.constraint(equalTo: bottomAnchor),
            
            widthAnchor.constraint(equalToConstant: 113)
        ])
    }
    
    // Configure button action
    public func configureButtonAction() {
        actionButton.addTarget(self, action: #selector(didTapActionButton), for: .touchUpInside)
    }
    
    // Button action handler
    @objc public func didTapActionButton() {
        onActionButtonTapped?() // Trigger the closure when the button is tapped
    }
}

//MARK: - Group Event Listeners for real time updates
extension GroupDetailsViewController: CometChatGroupDelegate, CometChatGroupEventListener{
    
    public func onGroupMemberJoined(action: ActionMessage, joinedUser: User, joinedGroup: Group) {
        if joinedGroup.guid == self.group?.guid {
            updateGroupInfo(joinedGroup) //updating group count
        }
    }
    
    public func onMemberAddedToGroup(action: ActionMessage, addedBy: User, addedUser: User, addedTo: Group) {
        if addedTo.guid == self.group?.guid {
            updateGroupInfo(addedTo) //updating group count
        }
    }
    
    public func onGroupMemberLeft(action: ActionMessage, leftUser: User, leftGroup: Group) {
        if leftGroup.guid == self.group?.guid {
            if CometChat.getLoggedInUser()?.uid == leftUser.uid{
                groupErrorView.isHidden = false
                self.view.isUserInteractionEnabled = false
                self.showHideOptions(hideViewMembers: true, hideAddMembers: true, hideBannMembers: true, hideLeaveGroup: true, hideDeleteGroup: true) //hiding all the options
            } else {
                if let scope = self.group?.scope{
                    leftGroup.scope = scope
                }
                updateGroupInfo(leftGroup)
            }
        }
    }
    
    public func onGroupMemberKicked(action: ActionMessage, kickedUser: User, kickedBy: User, kickedFrom: Group) {
        if kickedFrom.guid == self.group?.guid {
            if CometChat.getLoggedInUser()?.uid == kickedUser.uid{
                groupErrorView.isHidden = false
                self.view.isUserInteractionEnabled = false
                self.showHideOptions(hideViewMembers: true, hideAddMembers: true, hideBannMembers: true, hideLeaveGroup: true, hideDeleteGroup: true) //hiding all the options
            } else {
                if let scope = self.group?.scope{
                    kickedFrom.scope = scope
                }
                updateGroupInfo(kickedFrom)
            }
        }
    }
    
    public func onGroupMemberBanned(action: ActionMessage, bannedUser: User, bannedBy: User, bannedFrom: Group) {
        if bannedFrom.guid == self.group?.guid {
            if CometChat.getLoggedInUser()?.uid == bannedUser.uid{
                groupErrorView.isHidden = false
                self.view.isUserInteractionEnabled = false
                self.showHideOptions(hideViewMembers: true, hideAddMembers: true, hideBannMembers: true, hideLeaveGroup: true, hideDeleteGroup: true) //hiding all the options
            } else {
                if let scope = self.group?.scope{
                    bannedFrom.scope = scope
                }
                updateGroupInfo(bannedFrom)
            }
        }
    }
    
    public func onGroupMemberUnbanned(action: CometChatSDK.ActionMessage, unbannedUser: CometChatSDK.User, unbannedBy: CometChatSDK.User, unbannedFrom: CometChatSDK.Group) {
        if CometChat.getLoggedInUser()?.uid == unbannedUser.uid{
            groupErrorView.isHidden = true
            self.view.isUserInteractionEnabled = true
        }
    }
    
    public func onGroupMemberScopeChanged(action: ActionMessage, scopeChangeduser: User, scopeChangedBy: User, scopeChangedTo: String, scopeChangedFrom: String, group: Group) {
        if group.guid == self.group?.guid {
            
            //THIS NEED TO BE FIXED FROM THE BACKEND
            if scopeChangeduser.uid == CometChat.getLoggedInUser()?.uid {
                group.scope = CometChat.GroupMemberScopeType.from(string: scopeChangedTo) ?? group.scope
                action.receiver = group
                updateGroupInfo(group)
            }
            
        }
    }
    
    public func ccGroupMemberAdded(messages: [ActionMessage], usersAdded: [User], groupAddedIn: Group, addedBy: User) {
        if self.group?.guid == groupAddedIn.guid{
            updateGroupInfo(groupAddedIn)
        }
    }
    
    public func ccGroupMemberJoined(joinedUser: User, joinedGroup: Group) {
        if self.group?.guid == joinedGroup.guid{
            updateGroupInfo(joinedGroup)
        }
    }
    
    public func ccGroupMemberKicked(action: ActionMessage, kickedUser: User, kickedBy: User, kickedFrom: Group) {
        if self.group?.guid == kickedFrom.guid{
            updateGroupInfo(kickedFrom)
        }
    }
    
    public func ccGroupMemberBanned(action: ActionMessage, bannedUser: User, bannedBy: User, bannedFrom: Group) {
        if self.group?.guid == bannedFrom.guid{
            updateGroupInfo(bannedFrom)
        }
    }
    
    public func ccGroupMemberUnbanned(action: ActionMessage, unbannedUser: User, unbannedBy: User, unbannedFrom: Group) {
        if self.group?.guid == unbannedFrom.guid {
            updateGroupInfo(unbannedFrom)
        }
    }
    
    public func ccGroupMemberScopeChanged(action: ActionMessage, updatedUser: User, scopeChangedTo: String, scopeChangedFrom: String, group: Group) {
        if self.group?.guid == group.guid {
            updateGroupInfo(group)
        }
    }
    
    public func ccOwnershipChanged(group: Group, newOwner: GroupMember) {
        if self.group?.guid == group.guid {
            updateGroupInfo(group)
        }
    }
    
    public func updateGroupInfo(_ group: Group){
        if group.guid != self.group?.guid { return }
        DispatchQueue.main.async { [weak self] in
            guard let self = self else { return }
            self.group = group
            self.memberCountLabel.text = "\(group.membersCount) \(group.membersCount > 1 ? "MEMBERS".localize() : "MEMBER".localize())"
            if group.owner == CometChat.getLoggedInUser()?.uid{
                if group.membersCount == 1 {
                    self.showHideOptions(hideViewMembers: false, hideAddMembers: false, hideBannMembers: false, hideLeaveGroup: true, hideDeleteGroup: false)
                } else {
                    self.showHideOptions(hideViewMembers: false, hideAddMembers: false, hideBannMembers: false, hideLeaveGroup: false, hideDeleteGroup: false)
                }
            }else{
                switch group.scope{
                case .admin:
                    if group.membersCount == 1 {
                        self.showHideOptions(hideViewMembers: false, hideAddMembers: false, hideBannMembers: false, hideLeaveGroup: true, hideDeleteGroup: false)
                    } else {
                        self.showHideOptions(hideViewMembers: false, hideAddMembers: false, hideBannMembers: false, hideLeaveGroup: false, hideDeleteGroup: false)
                    }
                case .moderator:
                    self.showHideOptions(hideViewMembers: false, hideAddMembers: true, hideBannMembers: false, hideLeaveGroup: false, hideDeleteGroup: true)
                case .participant:
                    self.showHideOptions(hideViewMembers: false, hideAddMembers: true, hideBannMembers: true, hideLeaveGroup: false, hideDeleteGroup: true)
                
                @unknown default:
                    break
                }
            }
        }
    }
}
