//
//  HomeScreen.swift
//  CometChatUIKitSwift
//
//  Created by Suryansh on 17/10/24.
//

import UIKit
import AVFoundation
import CometChatUIKitSwift
import CometChatSDK
import SystemConfiguration
import CometChatBuilder

var isBugseeLaunched = false

public class HomeScreenViewController: UITabBarController {
    
    public lazy var conversations: CometChatConversations = {
        let conversations = CometChatConversations()
        conversations.set(onItemClick: { [weak self] conversation, indexPath in
            let messages = MessagesVC()
            messages.group = (conversation.conversationWith as? Group)
            messages.user = (conversation.conversationWith as? CometChatSDK.User)
            
            if let splitScreenCallBack = self?.splitScreenCallBack {
                splitScreenCallBack(messages)
            } else {
                self?.navigationController?.pushViewController(messages, animated: true)
            }
        })
        conversations.hideUserStatus = !CometChatBuilderSettings.shared.chatFeatures.coreMessagingExperience.userAndFriendsPresence
        conversations.hideReceipts = !CometChatBuilderSettings.shared.chatFeatures.coreMessagingExperience.messageDeliveryAndReadReceipts
        
        conversations.onSearchClick = {
            let searchVC = CometChatSearch()
            searchVC.hidesBottomBarWhenPushed = true
            
            searchVC.onConversationClicked = { [weak self] conversation, indexPath in
                    let messages = MessagesVC()
                    messages.group = (conversation.conversationWith as? Group)
                    messages.user = (conversation.conversationWith as? CometChatSDK.User)
                    
                    if let splitScreenCallBack = self?.splitScreenCallBack {
                        splitScreenCallBack(messages)
                    } else {
                        self?.navigationController?.pushViewController(messages, animated: true)
                    }
            }
            searchVC.onMessageClicked = { [weak self] message in
                let loggedInUID = CometChat.getLoggedInUser()?.uid
                if message.parentMessageId > 0{
                    CometChat.getMessageDetails(message.parentMessageId) { parentMessage in
                        let threadedView = ThreadedMessagesVC()
                        threadedView.parentMessage = parentMessage
                        threadedView.parentMessageView.controller = self
                        threadedView.targetMessageId = message.id
                        threadedView.parentMessageView.set(parentMessage: parentMessage)
                        self?.navigationController?.pushViewController(threadedView, animated: true)
                    } onError: { error in
                        print(error?.errorDescription ?? "")
                    }
                } else {
                    let messagesVC = MessagesVC() // or your custom MessageViewController
                    messagesVC.user = loggedInUID == message.sender?.uid ? (message.receiver as? CometChatSDK.User) : message.sender
                    messagesVC.group = message.receiver as? Group
                    messagesVC.targetMessageId = message.id

                    self?.navigationController?.pushViewController(messagesVC, animated: true)
                }
            }
            self.navigationController?.pushViewController(searchVC, animated: false)
        }
        return conversations
    }()
    
    #if canImport(CometChatCallsSDK)
    public lazy var calls: CometChatCallLogs = {
        let calls = CometChatCallLogs()
        calls.set(goToCallLogDetail: { [weak self] callLog, user, group in
            if let callLog = callLog as? CometChatCallsSDK.CallLog {
                let callDetails = CallLogDetailsVC()
                callDetails.currentUser = user
                callDetails.currentGroup = group
                callDetails.callLog = callLog
                callDetails.dateTimeFormatter = calls.dateTimeFormatter
                if let splitScreenCallBack = self?.splitScreenCallBack {
                    splitScreenCallBack(callDetails)
                } else {
                    self?.navigationController?.pushViewController(callDetails, animated: true)
                }
            }
        })
        return calls
    }()
    #endif
    
    public lazy var users: CometChatUsers = {
        let users = CometChatUsers()
        users.set(onItemClick: { [weak self] users, indexPath in
            let messages = MessagesVC()
            messages.user = users
            if let splitScreenCallBack = self?.splitScreenCallBack {
                splitScreenCallBack(messages)
            } else {
                self?.navigationController?.pushViewController(messages, animated: true)
            }
        })
        users.hideUserStatus = !CometChatBuilderSettings.shared.chatFeatures.coreMessagingExperience.userAndFriendsPresence
        return users
    }()
        
    public lazy var groups: CometChatGroups = {
                
        let groups = CometChatGroups()
        if CometChatBuilderSettings.shared.chatFeatures.groupManagement.createGroup{
            groups.rightBarButtonItem = [
                UIBarButtonItem(
                    image: UIImage(named: "groups-create"),
                    style: .done,
                    target: self,
                    action: #selector(tapCreate)
                )
            ]
        }else{
            groups.rightBarButtonItem = []
        }
        groups.joinPasswordProtectedGroup = { [weak self] group in
            let joinGroupVC = JoinPasswordProtectedGroupVC()
            joinGroupVC.group = group
            joinGroupVC.onGroupJoined = { [weak joinGroupVC] group in
                joinGroupVC?.dismiss(animated: true)
                let messages = MessagesVC()
                messages.group = group
                self?.navigationController?.pushViewController(messages, animated: true)
            }
            if let self = self {
                presentViewControllerBottomSheet(from: self, to: joinGroupVC, height: 378)
            }
        }
        groups.set(onItemClick: { [weak self] group, indexPath in
            let messages = MessagesVC()
            messages.group = group
            if let splitScreenCallBack = self?.splitScreenCallBack {
                splitScreenCallBack(messages)
            } else {
                self?.navigationController?.pushViewController(messages, animated: true)
            }
        })


        return groups
    }()
    
    public lazy var activityIndicator: UIActivityIndicatorView = {
        let activityIndicator = UIActivityIndicatorView()
        activityIndicator.translatesAutoresizingMaskIntoConstraints = false
        activityIndicator.backgroundColor = self.view.backgroundColor?.withAlphaComponent(0.5)
        return activityIndicator
    }()
    
    public lazy var lastSelectedIndex = 0
    var splitScreenCallBack: ((_ viewController: UIViewController) -> Void)?
    var loggedInUserAvatarImage: UIImage?
    
    override public func viewDidLoad() {
        super.viewDidLoad()
        setupTabs()
    }
    
    override public func viewWillAppear(_ animated: Bool) {
        self.navigationController?.setNavigationBarHidden(true, animated: false)
        
        let tabBarAppearance = UITabBarAppearance()
            tabBarAppearance.backgroundColor = CometChatTheme.backgroundColor01.withAlphaComponent(0.5)

            tabBarAppearance.selectionIndicatorImage = UIImage()

            let normalAttributes: [NSAttributedString.Key: Any] = [
                .font: CometChatTypography.Caption2.medium,
                .foregroundColor: UIColor.gray
            ]
            let selectedAttributes: [NSAttributedString.Key: Any] = [
                .font: CometChatTypography.Caption2.medium,
                .foregroundColor: CometChatTheme.primaryColor
            ]

            let item = tabBarAppearance.stackedLayoutAppearance
            item.normal.titleTextAttributes = normalAttributes
            item.normal.iconColor = .gray
            item.selected.titleTextAttributes = selectedAttributes
            item.selected.iconColor = CometChatTheme.primaryColor

            tabBar.standardAppearance = tabBarAppearance
            if #available(iOS 15.0, *) {
                tabBar.scrollEdgeAppearance = tabBarAppearance
            }

            UITabBar.appearance().selectionIndicatorImage = UIImage()

        
        super.viewWillAppear(animated)
        
        buildAvatarBarButtonItem()
    }
    
    override public func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
    }
    
    override public func tabBar(_ tabBar: UITabBar, didSelect item: UITabBarItem) {
        if lastSelectedIndex == self.selectedIndex {
            #if canImport(CometChatCallsSDK)
            switch self.selectedIndex {
            case 0:
                if let table = conversations.tableView, table.numberOfSections > 0{
                    if table.numberOfRows(inSection: 0) > 0{
                        table.scrollToRow(at: IndexPath(row: 0, section: 0), at: .top, animated: true)
                    }
                }
            case 1:
                if let table = calls.tableView, table.numberOfSections > 0{
                    if table.numberOfRows(inSection: 0) > 0{
                        table.scrollToRow(at: IndexPath(row: 0, section: 0), at: .top, animated: true)
                    }
                }
            case 2:
                if let table = users.tableView, table.numberOfSections > 0{
                    if table.numberOfRows(inSection: 0) > 0{
                        table.scrollToRow(at: IndexPath(row: 0, section: 0), at: .top, animated: true)
                    }
                }
            case 3:
                if let table = groups.tableView, table.numberOfSections > 0{
                    if table.numberOfRows(inSection: 0) > 0{
                        table.scrollToRow(at: IndexPath(row: 0, section: 0), at: .top, animated: true)
                    }
                }
            default:
                break
            }
            #else
            switch self.selectedIndex {
            case 0:
                if conversations.tableView.numberOfRows(inSection: 0) > 0{
                    conversations.tableView.scrollToRow(at: IndexPath(row: 0, section: 0), at: .top, animated: true)
                }
            case 1:
                if users.tableView.numberOfRows(inSection: 0) > 0{
                    users.tableView.scrollToRow(at: IndexPath(row: 0, section: 0), at: .top, animated: true)
                }
            case 2:
                if groups.tableView.numberOfRows(inSection: 0) > 0{
                    groups.tableView.scrollToRow(at: IndexPath(row: 0, section: 0), at: .top, animated: true)
                }
            default:
                break
            }
            #endif
        } else {
            lastSelectedIndex = self.selectedIndex
        }
    }
    
    public func buildAvatarBarButtonItem() {
        
        let customButton = UIButton(type: .custom)
        customButton.translatesAutoresizingMaskIntoConstraints = false
        
        let widthAnchor = customButton.widthAnchor.constraint(equalToConstant: 24)
        widthAnchor.priority = .required
        widthAnchor.isActive = true
        
        let heightAnchor = customButton.heightAnchor.constraint(equalToConstant: 24)
        heightAnchor.priority = .required
        heightAnchor.isActive = true

        if let imageURL = URL(string: "\(CometChat.getLoggedInUser()?.avatar ?? "")") {
            UIImageView.downloaded(from: imageURL) { image in
                if image == nil {
                    let image = UIImageView(frame: .init(origin: .zero, size: CGSize(width: 24, height: 24)))
                    customButton.setImage(AvatarUtils.setImageSnap(
                        text: CometChat.getLoggedInUser()?.name ?? "",
                        color: CometChatTheme.primaryColor,
                        textAttributes: [.font: CometChatTypography.Caption1.medium, .foregroundColor: CometChatTheme.white],
                        view: image
                    ), for: .normal)
                } else {
                    customButton.setImage(image, for: .normal)
                    customButton.imageView?.contentMode = .scaleAspectFill
                }
            }
        } else {
            let image = UIImageView(frame: .init(origin: .zero, size: CGSize(width: 24, height: 24)))
            customButton.setImage(AvatarUtils.setImageSnap(
                text: CometChat.getLoggedInUser()?.name ?? "",
                color: CometChatTheme.primaryColor,
                textAttributes: [.font: CometChatTypography.Caption1.medium, .foregroundColor: CometChatTheme.white],
                view: image
            ), for: .normal)
        }
        
        customButton.imageView?.layer.cornerRadius = 12
        customButton.imageView?.clipsToBounds = true
        let logoutBarButtonItem = UIBarButtonItem(customView: customButton)

        if #available(iOS 14.0, *) {
            let appVersion = Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String ?? "v5.0.0"
            let font = CometChatTypography.Heading4.regular  // Custom UIFont

            // Create actions with attributed titles
            let createAction = UIAction(title: "", image: UIImage(systemName: "plus.bubble.fill")) { _ in
                let startNewConversationNVC = CreateConversationVC()
                startNewConversationNVC.hidesBottomBarWhenPushed = true
                self.navigationController?.pushViewController(startNewConversationNVC, animated: true)
            }
            createAction.setValue(NSAttributedString(string: "CREATE_CONVERSATION".localize(), attributes: [.font: font]), forKey: "attributedTitle")

            let profileAction = UIAction(title: "", image: UIImage(systemName: "person.circle")) { _ in
                // No action
            }
            profileAction.setValue(NSAttributedString(string: "\(CometChat.getLoggedInUser()?.name ?? "")", attributes: [.font: font]), forKey: "attributedTitle")

            let logoutAction = UIAction(title: "", image: UIImage(systemName: "rectangle.portrait.and.arrow.right"), attributes: .destructive) { _ in
                self.logoutTapped()
            }
            logoutAction.setValue(NSAttributedString(string: "LOGOUT".localize(), attributes: [.font: font]), forKey: "attributedTitle")

            // Create and assign menu
            let menu = UIMenu(title: appVersion, children: [createAction, profileAction, logoutAction])
            customButton.menu = menu
            customButton.showsMenuAsPrimaryAction = true
        }
        
        logoutBarButtonItem.tintColor = CometChatTheme.primaryColor
        conversations.rightBarButtonItem = [logoutBarButtonItem]
    }
    
    //Logging out
    @objc public func logoutTapped() {
        if Reachability.isConnectedToNetwork(){
            CometChatNotifications.unregisterPushToken { success in
            } onError: { error in
                print(error.errorDescription)
            }
            CometChat.logout(onSuccess: { success in
                UserDefaults.standard.removeObject(forKey: "appID")
                UserDefaults.standard.removeObject(forKey: "region")
                UserDefaults.standard.removeObject(forKey: "authKey")
                AppConstants.APP_ID = ""
                AppConstants.AUTH_KEY = ""
                AppConstants.REGION = ""
                
                //Changing root window
                let sceneDelegate = UIApplication.shared.connectedScenes.first?.delegate as! SceneDelegate
                FrameworkManager.setRootViewController(UINavigationController(rootViewController: LoginWithUidVC()))
            }, onError: { error in
                print("logout failed with error: \(error.errorDescription)")
            })

        }else{
            print("logout failed with error: internet not connected")
        }
    }
    
    @objc public func tapCreate(){
        let vc = CreateGroupVC()
        vc.openGroupChat = { [weak self] group in
            let messages = MessagesVC()
            messages.group = group
            self?.navigationController?.pushViewController(messages, animated: true)
        }
        presentViewControllerBottomSheet(from: self, to: vc, height: 356)
    }
    
    public func setupTabs() {
        var controllers: [UIViewController] = []

        conversations.tabBarItem = UITabBarItem(title: "CHATS".localize(), image: UIImage(systemName: "message"), tag: 0)
        conversations.tabBarItem.selectedImage = UIImage(systemName: "message.fill")
        
        #if canImport(CometChatCallsSDK)
        calls.tabBarItem = UITabBarItem(title: "CALLS".localize(), image: UIImage(systemName: "phone"), tag: 1)
        calls.tabBarItem.selectedImage = UIImage(systemName: "phone.fill")
        #endif

        users.tabBarItem = UITabBarItem(title: "USERS".localize(), image: UIImage(systemName: "person"), tag: 2)
        users.tabBarItem.selectedImage = UIImage(systemName: "person.fill")

        groups.tabBarItem = UITabBarItem(title: "GROUPS".localize(), image: UIImage(systemName: "person.2"), tag: 3)
        groups.tabBarItem.selectedImage = UIImage(systemName: "person.2.fill")

        // Tabs to include
        let allowedTabs = CometChatBuilderSettings.shared.layout.tabs.map { $0.lowercased() }

        func shouldInclude(_ title: String) -> Bool {
            allowedTabs.contains(title.lowercased())
        }

        if shouldInclude("CHATS") {
            controllers.append(UINavigationController(rootViewController: conversations))
        }

        #if canImport(CometChatCallsSDK)
        if shouldInclude("CALLS") {
            controllers.append(UINavigationController(rootViewController: calls))
        }
        #endif

        if shouldInclude("USERS") {
            controllers.append(UINavigationController(rootViewController: users))
        }

        if shouldInclude("GROUPS") {
            controllers.append(UINavigationController(rootViewController: groups))
        }

        // Assign only allowed view controllers
        viewControllers = controllers

        tabBar.tintColor = CometChatTheme.primaryColor
        tabBar.isTranslucent = true
    }
}

extension UIViewController {
    public func presentViewControllerBottomSheet(from presentingVC: UIViewController, to viewControllerToPresent: UIViewController, height: Int) {
        if #available(iOS 15.0, *) {
            if let sheet = viewControllerToPresent.sheetPresentationController {
                if #available(iOS 16.0, *) {
                    let customDetent = UISheetPresentationController.Detent.custom { _ in
                        return CGFloat(height)
                    }
                    sheet.detents = [customDetent]
                }
                sheet.prefersGrabberVisible = true
                sheet.prefersScrollingExpandsWhenScrolledToEdge = false
            }
            viewControllerToPresent.modalPresentationStyle = .pageSheet
        } else {
            viewControllerToPresent.modalPresentationStyle = .pageSheet
        }

        presentingVC.present(viewControllerToPresent, animated: true, completion: nil)
    }
}

public class Reachability {

    public class func isConnectedToNetwork() -> Bool {

        var zeroAddress = sockaddr_in(sin_len: 0, sin_family: 0, sin_port: 0, sin_addr: in_addr(s_addr: 0), sin_zero: (0, 0, 0, 0, 0, 0, 0, 0))
        zeroAddress.sin_len = UInt8(MemoryLayout.size(ofValue: zeroAddress))
        zeroAddress.sin_family = sa_family_t(AF_INET)

        let defaultRouteReachability = withUnsafePointer(to: &zeroAddress) {
            $0.withMemoryRebound(to: sockaddr.self, capacity: 1) {zeroSockAddress in
                SCNetworkReachabilityCreateWithAddress(nil, zeroSockAddress)
            }
        }
        var flags: SCNetworkReachabilityFlags = SCNetworkReachabilityFlags(rawValue: 0)
        if SCNetworkReachabilityGetFlags(defaultRouteReachability!, &flags) == false {
            return false
        }
        let isReachable = (flags.rawValue & UInt32(kSCNetworkFlagsReachable)) != 0
        let needsConnection = (flags.rawValue & UInt32(kSCNetworkFlagsConnectionRequired)) != 0
        let ret = (isReachable && !needsConnection)

        return ret

    }
}
