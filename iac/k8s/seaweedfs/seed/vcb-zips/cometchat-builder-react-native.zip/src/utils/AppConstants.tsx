export const AppConstants = {
  fcmProviderId: '',
  apnsProviderId: '',
  authKey: '4152b0366478871f0fa8d19a287dd6f5ed5f8eff',
  appId: '26580020f03ff346',
  region: 'in',
  subscriptionType: 'ALL_USERS',
  versionNumber: 'V5.2.2',
  webClientId:
    '',
  iosClientId:
    '',
};

export const SCREEN_CONSTANTS = {
  LOGIN: 'Login',
  APP_CRED: 'AppCredentials',
  SAMPLE_USER: 'SampleUser',
  ONGOING_CALL_SCREEN: 'OngoingCallScreen',
  BOTTOM_TAB_NAVIGATOR: 'BottomTabNavigator',
  CHATS: 'Chats',
  CALLS: 'Calls',
  USERS: 'Users',
  GROUPS: 'Groups',
  CONVERSATION: 'Conversation',
  CREATE_CONVERSATION: 'CreateConversation',
  MESSAGES: 'Messages',
  THREAD_VIEW: 'ThreadView',
  USER_INFO: 'UserInfo',
  GROUP_INFO: 'GroupInfo',
  ADD_MEMBER: 'AddMember',
  TRANSFER_OWNERSHIP: 'TransferOwnershipSection',
  BANNED_MEMBER: 'BannedMember',
  VIEW_MEMBER: 'ViewMembers',
  CALL_LOGS: 'CallLogs',
  CALL_DETAILS: 'CallDetails',
  AI_AGENTS: 'AIAgents',
  QR_SCREEN: 'QRScreen',
} as const;
